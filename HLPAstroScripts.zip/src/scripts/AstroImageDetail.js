#feature-id   AstroImageDetail : HLP > Astro Image Detail
#feature-info This script helps sharpen both linear and non-linear data by use of BlurXterminator and wavelets through MMT and MLT

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>

// include constants
#include <pjsr/ImageOp.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/UndoFlag.jsh>

#ifeq __PI_PLATFORM__ MACOSX
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.2.mlpackage"
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.mlpackage"
#define STARXTERMINATOR_AI_FILE "StarXTerminator.lite.nonoise.11.mlpackage"
#endif

#ifeq __PI_PLATFORM__ MSWINDOWS
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.2.pb"
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.pb"
#define STARXTERMINATOR_AI_FILE "StarXTerminator.lite.nonoise.11.pb"
#endif

#ifeq __PI_PLATFORM__ LINUX
#define NOISEXTERMINATOR_AI_FILE "NoiseXTerminator.2.pb"
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.pb"
#define STARXTERMINATOR_AI_FILE "StarXTerminator.lite.nonoise.11.pb"
#endif

// define a global variable containing the script's parameters
var AstroImageDetailParameters = {
   LargeScale: 5,
   SmallScale: 1,
   showPreview: false,
   targetView: undefined,
   originalTargetView: undefined,
   applyNoiseXTerminator: false,
   denoise: 0.50,
   enableBlurXTerminator: false,
   sharpenNonStellar: 0.50,
   useStarXTerminator: true
};

   AstroImageDetailParameters.save = function () {
    console.noteln("Saving parameters...");
    Parameters.set("LargeScale", this.LargeScale);
    Parameters.set("SmallScale", this.SmallScale);
    Parameters.set("showPreview", this.showPreview);
    Parameters.set("applyNoiseXTerminator", this.applyNoiseXTerminator);
    Parameters.set("denoise", this.denoise); // Save denoise value
    Parameters.set("enableBlurXTerminator", this.enableBlurXTerminator); // Save BlurXTerminator state
    Parameters.set("sharpenNonStellar", this.sharpenNonStellar);
    Parameters.set("useStarXTerminator", this.useStarXTerminator); // Save StarXTerminator selection
    console.noteln("Parameters saved successfully.");
};

AstroImageDetailParameters.load = function () {
    console.noteln("Loading parameters...");
    if (Parameters.has("LargeScale")) this.LargeScale = Parameters.getReal("LargeScale");
    if (Parameters.has("SmallScale")) this.SmallScale = Parameters.getReal("SmallScale");
    if (Parameters.has("showPreview")) this.showPreview = Parameters.getBoolean("showPreview");
    if (Parameters.has("applyNoiseXTerminator")) this.applyNoiseXTerminator = Parameters.getBoolean("applyNoiseXTerminator");
    if (Parameters.has("denoise")) this.denoise = Parameters.getReal("denoise");
    if (Parameters.has("sharpenNonStellar")) this.sharpenNonStellar = Parameters.getReal("sharpenNonStellar");
    if (Parameters.has("useStarXTerminator")) this.useStarXTerminator = Parameters.getBoolean("useStarXTerminator"); // Load StarXTerminator selection

    if (Parameters.has("enableBlurXTerminator")) {
        this.enableBlurXTerminator = Parameters.getBoolean("enableBlurXTerminator");
    } else {
        this.enableBlurXTerminator = false;  // Only default if missing
    }

    console.noteln("Parameters loaded successfully.");
};

// ScrollControl class definition
function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        with (this.parent) {
            dragOrigin.x = x;
            dragOrigin.y = y;
            dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        with (this.parent) {
            if (dragging) {
                scrollPosition = new Point(scrollPosition).translatedBy(dragOrigin.x - x, dragOrigin.y - y);
                dragOrigin.x = x;
                dragOrigin.y = y;
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = (new Rect(x0, y0, x1, y1)).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();
        }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

// Global function to proportionally scale MLT layers
function getScaledLayers(scale) {
   const defaultLayers = [0.000, 0.100, 0.075, 0.050, 0.025, 0.000];
   return defaultLayers.map((bias) => bias * (scale / 5));
}

// Apply MLT to a view with the scaled layers
function applyMLT(view, scale) {
   let scaledLayers = getScaledLayers(scale);

   var P = new MultiscaleLinearTransform;
   P.layers = [
      [true, true, scaledLayers[0], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[1], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[2], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[3], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[4], false, 3.000, 1.00, 1],
      [true, true, scaledLayers[5], false, 3.000, 1.00, 1]
   ];
   P.transform = MultiscaleLinearTransform.prototype.StarletTransform;
   P.executeOn(view);
}

// Apply MMT to a view with the scaled layers
function applyMMT(view, scale) {
   let scaledLayers = getScaledLayers(scale); // Use the same proportional scaling

   var P = new MultiscaleMedianTransform;
   P.layers = [
      [true, true, scaledLayers[0], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[1], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[2], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[3], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[4], false, 1.0000, 1.00, 0.0000],
      [true, true, scaledLayers[5], false, 1.0000, 1.00, 0.0000]
   ];
   P.medianWaveletThreshold = 5.00; // Threshold remains fixed
   P.executeOn(view);
}

// Apply NoiseXTerminator to a target view
function applyNoiseXTerminator(view, denoise) {
    console.noteln("Starting NoiseXTerminator process...");
    try {
        let P = new NoiseXTerminator();
        P.ai_file = NOISEXTERMINATOR_AI_FILE; // Use platform-specific macro
        P.denoise = typeof denoise === "number" ? denoise : 0.50; // Use passed value or default to 0.50
        P.detail = 0.15;

        if (!P.executeOn(view)) {
            throw new Error("NoiseXTerminator execution failed.");
        }

        console.noteln("NoiseXTerminator applied successfully with denoise =", P.denoise);
    } catch (error) {
        console.criticalln("Error applying NoiseXTerminator:", error.message || error);
        new MessageBox("NoiseXTerminator failed to execute.", "Error", StdIcon_Error, StdButton_Ok).execute();
    }
}

function AstroImageDetailDialog() {
   this.__base__ = Dialog;
   this.__base__();
   this.windowTitle = "Astro Image Detail";

this.debounceTimer = null; // Timer to delay preview updates
this.debounceDelay = 300;  // Delay in milliseconds (adjust as needed)
   this.title = new Label(this);
   this.title.text = "Astro Image Detail";
   this.title.textAlignment = TextAlign_Center;
   this.title.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0;";
   this.title.minHeight = 40;
   this.title.maxHeight = 50;

   this.description = new TextBox(this);
this.description.text =
   "Select your image from the dropdown to begin sharpening\n\n" +
   "If using linear data, please enable BlurXterminator.\n" +
   "Note that BlurXterminator is required for this function to operate.\n" +
   "Choose which star removal method is preferred for BlurXterminator Sharpening.\n" +
   "Move the Sharpen Non-Stellar slider to increase or decrease sharpening.\n\n" +
   "Small scale and large scale is best for stretched data.\n" +
   "Move Large Structure slider to increase or decrease large structure sharpening.\n" +
   "5 is a good starting point for both OSC and Mono.\n" +
   "Move Small Structure slider to increase or decrease small structure sharpening\n" +
   "OSC: 1 is a good starting point.\n" +
   "Mono 2x Drizzle: 5 is a good starting point.\n\n" +
   "Select Apply NoiseXterminator and set the denoise strength to reduce created noise.\n" +
   "Note that NoiseXterminator is required for this function to operate.\n\n" +
   "Written by Tony De Nardo";

this.description.readOnly = true;
this.description.minHeight = 400; // Adjust height for better spacing
this.description.minWidth = 400;

// Set background, alignment, font size, and font family to Sans-serif
this.description.styleSheet =
   "background-color: #d3d3d3;" + // Grey background color
   "font-size: 8pt;" +          // Slightly larger font
   "font-family: Sans-serif;" +  // Sans-serif font
   "text-align: center;" +       // Center the text
   "padding: 10px;";             // Add padding for better readability

   // Find the active window
   let activeWindow = ImageWindow.activeWindow;
   if (!activeWindow.isNull) {
      AstroImageDetailParameters.targetView = activeWindow.mainView;
   } else {
      AstroImageDetailParameters.targetView = null;
   }

   // add a view picker
   // Add a view picker
this.viewList = new ViewList(this);
this.viewList.getAll();

// ✅ Ensure the correct target view is selected when opening the script
if (AstroImageDetailParameters.originalTargetView) {
    this.viewList.currentView = AstroImageDetailParameters.originalTargetView;
    console.noteln("✅ Restored original target view:", AstroImageDetailParameters.originalTargetView.fullId);
} else if (AstroImageDetailParameters.targetView) {
    this.viewList.currentView = AstroImageDetailParameters.targetView;
}

// Handle user selection of a new view
this.viewList.onViewSelected = function(view) {
    AstroImageDetailParameters.targetView = view;

    // ✅ Preserve the first selected view as the "original" target
    if (!AstroImageDetailParameters.originalTargetView) {
        AstroImageDetailParameters.originalTargetView = view;
        console.noteln("🔒 Stored original target view:", view.fullId);
    }
}.bind(this);

// Add a label for non-linear sharpening method selection
this.nonLinearAdjustmentLabel = new Label(this);
this.nonLinearAdjustmentLabel.text = "For Non-Linear Sharpening, Adjust Large and Small Scale Sliders";
this.nonLinearAdjustmentLabel.textAlignment = TextAlign_Center;
this.nonLinearAdjustmentLabel.styleSheet = "font-weight: bold; color: #808080; font-size: 10pt;";

   // create the input slider for Large Scale Structure
   this.LargeScaleControl = new NumericControl(this);
   this.LargeScaleControl.label.text = "Large Scale Structure:";
   this.LargeScaleControl.label.width = 120;
   this.LargeScaleControl.setRange(0, 8);
   this.LargeScaleControl.setPrecision(2);
   this.LargeScaleControl.slider.setRange(0, 100);
   this.LargeScaleControl.setValue(AstroImageDetailParameters.LargeScale); // Set the default value
   this.LargeScaleControl.toolTip = "<p>Adjust above 5 with caution.</p>";
   this.LargeScaleControl.onValueUpdated = function(value) {
   AstroImageDetailParameters.LargeScale = value;
}.bind(this);

// Adjusted onValueUpdated for the slider
this.LargeScaleControl.onValueUpdated = function(value) {
   AstroImageDetailParameters.LargeScale = value;
}.bind(this);

   this.SmallScaleStructureControl = new NumericControl(this);
this.SmallScaleStructureControl.label.text = "Small Scale Structure:";
this.SmallScaleStructureControl.label.width = 120;
this.SmallScaleStructureControl.setRange(0, 8);
this.SmallScaleStructureControl.setPrecision(2);
this.SmallScaleStructureControl.slider.setRange(0, 100);
this.SmallScaleStructureControl.setValue(AstroImageDetailParameters.SmallScale);
this.SmallScaleStructureControl.toolTip = "<p>Adjust the small scale structure amount.</p>";
this.SmallScaleStructureControl.onValueUpdated = function (value) {
   AstroImageDetailParameters.SmallScale = value;
   }.bind(this);

// Add label to indicate BlurXTerminator usage
this.blurXTerminatorLabel = new Label(this);
this.blurXTerminatorLabel.text = "For Linear Sharpening, Enable BlurXterminator";
this.blurXTerminatorLabel.textAlignment = TextAlign_Center;
this.blurXTerminatorLabel.styleSheet = "font-weight: bold; color: #808080; font-size: 10pt;";

// Add BlurXTerminator checkbox
this.blurXTerminatorCheckBox = new CheckBox(this);
this.blurXTerminatorCheckBox.text = "Enable BlurXTerminator";
this.blurXTerminatorCheckBox.checked = false; // Default unchecked
this.blurXTerminatorCheckBox.toolTip = "<p>Enable this option to use BlurXTerminator for AI-based sharpening.</p>";
this.blurXTerminatorCheckBox.onCheck = function(checked) {
   AstroImageDetailParameters.enableBlurXTerminator = checked;

   // Disable Large Scale and Small Scale sliders when BlurXTerminator is enabled
   this.LargeScaleControl.enabled = !checked;
   this.SmallScaleStructureControl.enabled = !checked;

   // Enable Sharpen Non-Stellar slider only if BlurXTerminator is enabled
   this.sharpenNonStellarControl.enabled = checked;
}.bind(this);

// Add Sharpen Non-Stellar slider (only active when BlurXTerminator is enabled)
this.sharpenNonStellarControl = new NumericControl(this);
this.sharpenNonStellarControl.label.text = "Sharpen Non-Stellar:";
this.sharpenNonStellarControl.label.width = 120;
this.sharpenNonStellarControl.setRange(0, 1.0); // Range from 0 to 1.0
this.sharpenNonStellarControl.setPrecision(2); // Two decimal places
this.sharpenNonStellarControl.slider.setRange(0, 100); // Slider resolution
this.sharpenNonStellarControl.setValue(0.50); // Default BlurXTerminator value
this.sharpenNonStellarControl.toolTip = "<p>Adjust the sharpening strength for non-stellar structures.</p>";
this.sharpenNonStellarControl.enabled = false; // Starts disabled

// Add a label for the star removal method selection
this.starRemovalMethodLabel = new Label(this);
this.starRemovalMethodLabel.text = "Star Removal Method for BlurXterminator:";
this.starRemovalMethodLabel.textAlignment = TextAlign_Center;
this.starRemovalMethodLabel.styleSheet = "font-weight: bold; color: #808080; font-size: 10pt;";

// Create a horizontal sizer for radio buttons
this.starRemovalSizer = new HorizontalSizer;
this.starRemovalSizer.margin = 4;
this.starRemovalSizer.spacing = 6;

// Create StarXTerminator radio button
this.starXTerminatorRadio = new RadioButton(this);
this.starXTerminatorRadio.text = "StarXTerminator";
this.starXTerminatorRadio.checked = true; // Default to StarXTerminator
this.starXTerminatorRadio.toolTip = "Use StarXTerminator for star removal.";
this.starXTerminatorRadio.onCheck = function(checked) {
    if (checked) {
        AstroImageDetailParameters.useStarXTerminator = true;
        console.noteln("✅ StarXTerminator selected for star removal.");
    }
}.bind(this);

// Create StarNet++ radio button
this.starNetRadio = new RadioButton(this);
this.starNetRadio.text = "StarNet++";
this.starNetRadio.checked = false; // Default to unchecked
this.starNetRadio.toolTip = "Use StarNet++ for star removal.";
this.starNetRadio.onCheck = function(checked) {
    if (checked) {
        AstroImageDetailParameters.useStarXTerminator = false;
        console.noteln("✅ StarNet++ selected for star removal.");
    }
}.bind(this);

// Add radio buttons to the sizer
this.starRemovalSizer.add(this.starXTerminatorRadio);
this.starRemovalSizer.addSpacing(8);
this.starRemovalSizer.add(this.starNetRadio);

// Update parameter when the value changes
this.sharpenNonStellarControl.onValueUpdated = function (value) {
   AstroImageDetailParameters.sharpenNonStellar = value;
}.bind(this);

// Add a label for NoiseXterminator selection
this.NoiseXterminatorLabel = new Label(this);
this.NoiseXterminatorLabel.text = "Enable NoiseXterminator to Reduce Image Noise";
this.NoiseXterminatorLabel.textAlignment = TextAlign_Center;
this.NoiseXterminatorLabel.styleSheet = "font-weight: bold; color: #808080; font-size: 10pt;";

// Add NoiseXTerminator checkbox
this.noiseXTerminatorCheckBox = new CheckBox(this);
this.noiseXTerminatorCheckBox.text = "Apply NoiseXTerminator";
this.noiseXTerminatorCheckBox.checked = false; // Default unchecked
this.noiseXTerminatorCheckBox.toolTip = "<p>Enable this option to apply NoiseXTerminator after sharpening.</p>";
this.noiseXTerminatorCheckBox.onCheck = function(checked) {
   AstroImageDetailParameters.applyNoiseXTerminator = checked;
}.bind(this);

// Add Denoise slider for NoiseXTerminator
this.DenoiseControl = new NumericControl(this);
this.DenoiseControl.label.text = "Denoise Strength:";
this.DenoiseControl.label.width = 120;
this.DenoiseControl.setRange(0, 1.0); // Slider range from 0 to 1.0
this.DenoiseControl.setPrecision(2); // Two decimal places
this.DenoiseControl.slider.setRange(0, 100); // Slider resolution
this.DenoiseControl.setValue(AstroImageDetailParameters.denoise || 0.50); // Default value for P.denoise
this.DenoiseControl.toolTip = "<p>Adjust the denoise strength for NoiseXTerminator.</p>";

// Update the parameter when the slider value changes
this.DenoiseControl.onValueUpdated = function (value) {
   // Update the denoise value in parameters without triggering a preview update
   AstroImageDetailParameters.denoise = value;
   }.bind(this);

   // Add create instance button
   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = () => {
      // stores the parameters
      AstroImageDetailParameters.save();
      // create the script instance
      this.newInstance();
   };

   // Create zoom dropdown
this.zoomLabel = new Label(this);
this.zoomLabel.text = "Zoom: ";
this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

this.zoomComboBox = new ComboBox(this);
this.zoomComboBox.addItem("1:1");
this.zoomComboBox.addItem("1:2");
this.zoomComboBox.addItem("1:4");
this.zoomComboBox.addItem("1:8");
this.zoomComboBox.addItem("Fit to Preview");
this.zoomComboBox.currentItem = 2; // Set default to "1:4"
this.zoomComboBox.minWidth = 120; // Set minimum width
this.zoomComboBox.onItemSelected = (index) => {
   let zoomFactor;
   switch (index) {
      case 0: zoomFactor = -1; break; // 1:1
      case 1: zoomFactor = -2; break; // 1:2
      case 2: zoomFactor = -4; break; // 1:4
      case 3: zoomFactor = -8; break; // 1:8
      case 4: // Fit to Preview
         const previewWidth = this.previewControl.viewport.width;
         const imageWidth = this.previewControl.getImage() ? this.previewControl.getImage().width : 1;
         zoomFactor = -Math.max(1, Math.floor(imageWidth / previewWidth));
         break;
      default: zoomFactor = -4; // Default to 1:4
   }

   // Update zoom factor and refresh preview
   this.previewControl.zoomFactor = zoomFactor;
   if (AstroImageDetailParameters.showPreview) {
      this.refreshPreview();
   }
};

// Update refreshPreview to apply AutoSTF when BlurXTerminator is enabled
AstroImageDetailDialog.prototype.refreshPreview = function () {
    if (AstroImageDetailParameters.showPreview && this.viewList.currentView) {
        console.noteln("🔄 Refreshing preview...");

        // ✅ Ensure the preview uses the selected view, not the workspace
        let selectedView = this.viewList.currentView;
        if (!selectedView || selectedView.isNull) {
            console.warningln("🚨 No valid view selected. Cannot refresh preview.");
            return;
        }

        let dialog = new AstroImageDetailDialog();
        let psfDiameter = null; // Default to null, only measure if needed

// ✅ Step 1: **Only search for stars image & measure PSF if BlurXTerminator is enabled**
        let starsView = null;
        let usingStarsImage = false;

        if (AstroImageDetailParameters.enableBlurXTerminator) {
            console.noteln("🟢 BlurXTerminator is enabled. Checking for stars-only image...");

            starsView = dialog.findStarsImage(selectedView);
            usingStarsImage = starsView !== null;

            if (usingStarsImage) {
                console.noteln("✅ Using stars-only image for PSF measurement.");
            } else {
                console.noteln("❌ No stars-only image found. Measuring PSF from main image.");
            }

            let psfSourceView = usingStarsImage ? starsView : selectedView;
            psfDiameter = dialog.measurePSF(psfSourceView);

            if (psfDiameter === null) {
                console.warningln("🚨 No stars detected. Cannot proceed.");
                return;
            }
        }

        // ✅ Step 2: Create TEMP IMAGE for preview processing
        let tempWindow = new ImageWindow(
            selectedView.image.width, selectedView.image.height,
            selectedView.image.numberOfChannels,
            selectedView.image.bitsPerSample,
            selectedView.image.isReal,
            selectedView.image.isColor
        );

        tempWindow.mainView.beginProcess();
        tempWindow.mainView.image.assign(selectedView.image);
        tempWindow.mainView.endProcess();
        let tempView = tempWindow.mainView;

        console.noteln("✅ Using original selected view for preview:", selectedView.fullId);

        // ✅ Step 3: If no stars-only image was found, remove stars from temp image
        if (AstroImageDetailParameters.enableBlurXTerminator && !starsView) {
            console.noteln("❌ No pre-existing stars image found. Removing stars from temp image...");
            starsView = dialog.removeStars(tempView);

            if (!starsView) {
                console.warningln("🚨 Star removal failed. Cannot proceed.");
                new MessageBox("Star removal failed.", "Error", StdIcon_Error, StdButton_Ok).execute();
                tempWindow.forceClose();
                return;
            }
        }

        // ✅ Step 4: Apply BlurXTerminator or MLT/MMT to TEMP IMAGE
        if (AstroImageDetailParameters.enableBlurXTerminator) {
            console.noteln("🟢 Applying BlurXTerminator in preview...");
            psfDiameter = Math.min(psfDiameter, 8);
            dialog.applyBlurXTerminator(tempView, psfDiameter);
        } else {
            console.noteln("🔵 Using default sharpening workflow (MLT/MMT) for preview.");
            if (AstroImageDetailParameters.LargeScale > 0) applyMLT(tempView, AstroImageDetailParameters.LargeScale);
            if (AstroImageDetailParameters.SmallScale > 0) applyMMT(tempView, AstroImageDetailParameters.SmallScale);
        }

        // ✅ Step 5: Apply NoiseXTerminator if enabled
        if (AstroImageDetailParameters.applyNoiseXTerminator) {
            console.noteln("✅ Preview: Applying NoiseXTerminator...");
            applyNoiseXTerminator(tempView, AstroImageDetailParameters.denoise);
        }

        // ✅ Step 6: **Only recombine stars if BlurXTerminator was applied AND a stars image did NOT already exist**
if (AstroImageDetailParameters.enableBlurXTerminator && !usingStarsImage) {
    console.noteln("🔹 No pre-existing stars image detected. Recombining extracted stars...");

    if (!dialog.restoreStars(tempView)) {
        console.warningln("❌ Star restoration failed. Cannot proceed.");
        new MessageBox("Star restoration failed.", "Error", StdIcon_Error, StdButton_Ok).execute();
        cleanupTempFiles();
        return;
    }

    console.noteln("✅ Star recombination completed successfully!");
} else {
    console.noteln("✅ A pre-existing stars image was found. Skipping star recombination.");
}

        // ✅ Step 7: **Apply AutoSTF using PixelMath**
        console.noteln("✅ Preview: Applying AutoSTF using PixelMath...");

        let imageMin = tempView.image.minimum();
        let imageMedian = tempView.image.median();
        const targetMedian = 0.25;

        // **First PixelMath operation: ($T - min($T)) / (1 - min($T))**
        let pixelMath1 = new PixelMath();
        if (tempView.image.numberOfChannels === 1) {
            pixelMath1.expression = "($T - " + imageMin + ") / (1 - " + imageMin + ")";
        } else {
            pixelMath1.expression =
                "MedColor=avg(med($T[0]),med($T[1]),med($T[2]));\n" +
                "MinColor=min(min($T[0]),min($T[1]),min($T[2]));\n" +
                "SDevColor=avg(sdev($T[0]),sdev($T[1]),sdev($T[2]));\n" +
                "BlackPoint = MinColor;\n" +
                "Rescaled = ($T - BlackPoint) / (1 - BlackPoint);";
            pixelMath1.symbols = "BlackPoint, Rescaled, MedColor, MinColor, SDevColor";
        }
        pixelMath1.useSingleExpression = true;
        pixelMath1.executeOn(tempView);

        // **Second PixelMath operation: STF-like stretch**
        let pixelMath2 = new PixelMath();
        if (tempView.image.numberOfChannels === 1) {
            pixelMath2.expression =
                "((Med($T)-1)*0.25*$T)/(Med($T)*(0.25+$T-1)-0.25*$T)";
        } else {
            pixelMath2.expression =
                "MedianColor = avg(Med($T[0]),Med($T[1]),Med($T[2]));\n" +
                "((MedianColor - 1) * " + targetMedian + " * $T) / (MedianColor * (" + targetMedian + " + $T - 1) - " + targetMedian + " * $T)";
            pixelMath2.symbols = "L, MedianColor, S";
        }
        pixelMath2.useSingleExpression = true;
        pixelMath2.executeOn(tempView);

        // ✅ Step 8: Resize for preview display
        let resample = new IntegerResample();
        resample.zoomFactor = this.previewControl.zoomFactor || -4;
        resample.executeOn(tempView);

        // ✅ Step 9: Update the preview control
        this.previewControl.doUpdateImage(new Image(tempView.image));

        // ✅ Step 10: Close the temporary window
        tempWindow.forceClose();
        console.noteln("✅ Preview updated successfully.");
    }
};

// Create preview refresh button
this.previewRefreshButton = new PushButton(this);
this.previewRefreshButton.text = "Refresh Preview";
this.previewRefreshButton.minWidth = 120; // Set minimum width
this.previewRefreshButton.onClick = () => {
   this.refreshPreview();
};

   // Create a sizer for zoom controls and refresh button
this.zoomSizer = new HorizontalSizer;
this.zoomSizer.margin = 4;
this.zoomSizer.spacing = 4;
this.zoomSizer.add(this.zoomLabel);
this.zoomSizer.add(this.zoomComboBox);
this.zoomSizer.addSpacing(12);
this.zoomSizer.add(this.previewRefreshButton);

   // prepare the execution button
   this.execButton = new PushButton(this);
   this.execButton.text = "Execute";
   this.execButton.width = 80; // Increased width
   this.execButton.onClick = () => {
      this.applySharpeningToMainImage();
      this.ok();
   };

   // create a horizontal slider to layout the execution button
   this.execButtonSizer = new HorizontalSizer;
   this.execButtonSizer.margin = 8;
   this.execButtonSizer.add(this.newInstanceButton)
   this.execButtonSizer.addSpacing(12);
   this.execButtonSizer.add(this.zoomSizer);
   this.execButtonSizer.addStretch();
   this.execButtonSizer.add(this.execButton)

   // Create a preview control
   this.previewControl = new ScrollControl(this);
   this.previewControl.setMinWidth(300);  // Set minimum width to avoid taking too much space
   this.previewControl.setMinHeight(300); // Set minimum height
   this.previewControl.visible = false;   // Hide preview control initially

   // layout the dialog
this.leftSizer = new VerticalSizer;
this.leftSizer.margin = 8;
this.leftSizer.spacing = 8;
this.leftSizer.add(this.title);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.description);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.viewList);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.nonLinearAdjustmentLabel);
this.leftSizer.addSpacing(4);
this.leftSizer.add(this.LargeScaleControl);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.SmallScaleStructureControl);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.blurXTerminatorLabel);
this.leftSizer.addSpacing(4);
this.leftSizer.add(this.blurXTerminatorCheckBox);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.sharpenNonStellarControl);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.starRemovalMethodLabel);
this.leftSizer.add(this.starRemovalSizer);
this.leftSizer.addSpacing(8);

// Add NoiseXTerminator checkbox
this.leftSizer.add(this.NoiseXterminatorLabel);
this.leftSizer.addSpacing(4);
this.leftSizer.add(this.noiseXTerminatorCheckBox);
this.leftSizer.addSpacing(8); // Add spacing after the checkbox

// Add DenoiseControl slider
this.leftSizer.add(this.DenoiseControl);
this.leftSizer.addSpacing(45);

// Create the checkbox for Show Preview
this.showPreviewCheckBox = new CheckBox(this);
this.showPreviewCheckBox.text = "Show Preview";
this.showPreviewCheckBox.checked = AstroImageDetailParameters.showPreview;
this.showPreviewCheckBox.toolTip = "<p>Enable or disable preview of the stretch.</p>";
this.showPreviewCheckBox.onCheck = function (checked) {
   AstroImageDetailParameters.showPreview = checked;
   this.previewControl.visible = checked; // Ensure preview visibility toggles correctly
   this.zoomSizer.visible = checked;

   if (checked && AstroImageDetailParameters.targetView) {
      this.refreshPreview(); // Update preview when checked
   }

   this.adjustToContents();
}.bind(this);

// Add Show Preview checkbox
this.leftSizer.add(this.showPreviewCheckBox);
this.leftSizer.addSpacing(8);
this.leftSizer.add(this.execButtonSizer);
this.leftSizer.addStretch();
this.leftSizer.minWidth = 300; // Set minimum width for left sizer

   this.mainSizer = new HorizontalSizer;
   this.mainSizer.margin = 8;
   this.mainSizer.spacing = 8;
   this.mainSizer.add(this.leftSizer);
   this.mainSizer.add(this.previewControl, 1, Align_Expand);  // Ensure preview control gets allocated proper space

   this.sizer = this.mainSizer;

   this.adjustToContents();

   this.onShow = () => {
      this.previewControl.visible = false;
      this.zoomSizer.visible = false;
      this.adjustToContents();
   };

   this.createAndDisplayTemporaryImage = function(selectedImage) {
   let window = new ImageWindow(
      selectedImage.width, selectedImage.height,
      selectedImage.numberOfChannels,
      selectedImage.bitsPerSample,
      selectedImage.isReal,
      selectedImage.isColor
   );

   window.mainView.beginProcess();
   window.mainView.image.assign(selectedImage);
   window.mainView.endProcess();

   // Apply MLT for preview using the global applyMLT function
   applyMLT(window.mainView, AstroImageDetailParameters.LargeScale);

   // Resize for preview display
   var resample = new IntegerResample;
   resample.zoomFactor = -4; // Default zoom for preview
   resample.executeOn(window.mainView);

   let resizedImage = new Image(window.mainView.image);
   window.forceClose();

   return resizedImage;
};

   this.adjustToContents();
}

AstroImageDetailDialog.prototype = new Dialog;

AstroImageDetailDialog.prototype.assignParameters = function () {
   if (Parameters.has("LargeScale")) AstroImageDetailParameters.LargeScale = Parameters.getReal("LargeScale");
   if (Parameters.has("SmallScale")) AstroImageDetailParameters.SmallScale = Parameters.getReal("SmallScale");
   if (Parameters.has("showPreview")) AstroImageDetailParameters.showPreview = Parameters.getBoolean("showPreview");
   if (Parameters.has("applyNoiseXTerminator")) AstroImageDetailParameters.applyNoiseXTerminator = Parameters.getBoolean("applyNoiseXTerminator");
   if (Parameters.has("denoise")) AstroImageDetailParameters.denoise = Parameters.getReal("denoise");
   if (Parameters.has("enableBlurXTerminator")) AstroImageDetailParameters.enableBlurXTerminator = Parameters.getBoolean("enableBlurXTerminator");
   if (Parameters.has("sharpenNonStellar")) AstroImageDetailParameters.sharpenNonStellar = Parameters.getReal("sharpenNonStellar");
   if (Parameters.has("useStarXTerminator")) AstroImageDetailParameters.useStarXTerminator = Parameters.getBoolean("useStarXTerminator");
};

AstroImageDetailDialog.prototype.applySharpeningToMainImage = function () {
    if (!AstroImageDetailParameters.targetView) {
        console.warningln("❌ No target view is specified. Cannot proceed.");
        cleanupTempFiles();
        return;
    }

    console.noteln("🔍 Target view detected: " + AstroImageDetailParameters.targetView.fullId);

    let dialog = new AstroImageDetailDialog();
    let psfDiameter = null; // ✅ Declared only once, like in refreshPreview
    let starsView = null;
    let usingStarsImage = false;

    // ✅ Step 1: Search for an existing stars-only image (_stars, _star_mask)
    if (AstroImageDetailParameters.enableBlurXTerminator) {
        console.noteln("🟢 BlurXTerminator is enabled. Checking for stars-only image...");

        starsView = dialog.findStarsImage(AstroImageDetailParameters.targetView);
        usingStarsImage = starsView !== null;

        if (usingStarsImage) {
            console.noteln("✅ Using stars-only image for PSF measurement.");
        } else {
            console.noteln("❌ No stars-only image found. Measuring PSF from main image.");
        }

        let psfSourceView = usingStarsImage ? starsView : AstroImageDetailParameters.targetView;
        psfDiameter = dialog.measurePSF(psfSourceView);

        if (psfDiameter === null) {
            console.warningln("🚨 No stars detected. Cannot proceed.");
            new MessageBox("No stars detected and no _stars image found.", "Error", StdIcon_Error, StdButton_Ok).execute();
            cleanupTempFiles();
            return;
        }
    }

    // ✅ Step 2: If no stars-only image was found, extract stars from the target image
    if (AstroImageDetailParameters.enableBlurXTerminator && !starsView) {
        console.noteln("❌ No pre-existing stars image found. Removing stars from target image...");
        starsView = dialog.removeStars(AstroImageDetailParameters.targetView);

        if (!starsView) {
            console.warningln("🚨 Star removal failed. Cannot proceed.");
            new MessageBox("Star removal failed.", "Error", StdIcon_Error, StdButton_Ok).execute();
            cleanupTempFiles();
            return;
        }
    }

    // ✅ Step 3: Apply BlurXTerminator with measured PSF
    if (AstroImageDetailParameters.enableBlurXTerminator) {
        console.noteln("🟢 Applying BlurXTerminator...");
        psfDiameter = Math.min(psfDiameter, 8);
        dialog.applyBlurXTerminator(AstroImageDetailParameters.targetView, psfDiameter);
    } else {
        console.noteln("🔵 Using default sharpening workflow (MLT and MMT).");

        if (AstroImageDetailParameters.LargeScale > 0) {
            console.noteln("🔵 Applying MLT (LargeScale =", AstroImageDetailParameters.LargeScale, ")");
            applyMLT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.LargeScale);
        }

        if (AstroImageDetailParameters.SmallScale > 0) {
            console.noteln("🔵 Applying MMT (SmallScale =", AstroImageDetailParameters.SmallScale, ")");
            applyMMT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.SmallScale);
        }
    }

    // ✅ Step 4: Apply NoiseXTerminator if enabled
    if (AstroImageDetailParameters.applyNoiseXTerminator) {
        console.noteln("✅ Applying NoiseXTerminator...");
        applyNoiseXTerminator(AstroImageDetailParameters.targetView, AstroImageDetailParameters.denoise);
    } else {
        console.noteln("🚫 NoiseXTerminator not applied (checkbox is unchecked).");
    }

    // ✅ Step 5: **Only recombine stars if BlurXTerminator was applied AND a stars image did NOT already exist**
if (AstroImageDetailParameters.enableBlurXTerminator && !usingStarsImage) {
    console.noteln("🔹 No pre-existing stars image detected. Recombining extracted stars...");

    if (!dialog.restoreStars(AstroImageDetailParameters.targetView)) {
        console.warningln("❌ Star restoration failed. Cannot proceed.");
        new MessageBox("Star restoration failed.", "Error", StdIcon_Error, StdButton_Ok).execute();
        cleanupTempFiles();
        return;
    }

    console.noteln("✅ Star recombination completed successfully!");
} else {
    console.noteln("✅ A pre-existing stars image was found. Skipping star recombination.");
}

    cleanupTempFiles();
};

// Global array to track temporary files
var tempFiles = [];

// Function to save a view as a temporary file
function saveViewAsTemporaryFile(view) {
    if (!view || view.isNull) {
        console.warningln("❌ Error: Invalid view provided.");
        return null;
    }

    let tempDir = File.systemTempDirectory;
    let tempFilePath = tempDir + "/tempImage_" + new Date().getTime() + ".xisf";

    try {
        let window = view.window;
        if (!window || window.isNull) {
            console.warningln("❌ Failed to retrieve ImageWindow.");
            return null;
        }

        if (!window.saveAs(tempFilePath, false, false, false, false)) {
            console.warningln("❌ Failed to save temp image: " + tempFilePath);
            return null;
        }

        // ✅ Track temp file for later deletion
        tempFiles.push(tempFilePath);
        console.noteln("✅ Temp image saved: " + tempFilePath);
        return tempFilePath;
    } catch (error) {
        console.criticalln("❌ Exception saving temp file: " + error.message);
        return null;
    }
}

// Function to clean up temporary files
function cleanupTempFiles() {

    for (let i = 0; i < tempFiles.length; i++) {
        let filePath = tempFiles[i];

        if (File.exists(filePath)) {
            try {
                File.remove(filePath);
                console.noteln("✅ Deleted temp file: " + filePath);
            } catch (error) {
                console.warningln("❌ Failed to delete temp file: " + filePath + " Error: " + error.message);
            }
        } else {

        }
    }

    // Clear the tempFiles array after deletion
    tempFiles.length = 0;
    console.noteln("🧹 Temp file cleanup completed.");
}

function measureFWHM(imagePath, view) {
    console.noteln("Measuring FWHM using SubframeSelector on:", imagePath);

    let P = new SubframeSelector();
    P.routine = SubframeSelector.prototype.MeasureSubframes;
    P.nonInteractive = true;
    P.subframes = [[true, imagePath, "", ""]];
    P.fileCache = true;

    // ✅ FIX: Ensure a numeric value is assigned
    P.structureLayers = 5; // Set to a valid number (e.g., 5)

    P.sensitivity = 0.4;
    P.psfFit = SubframeSelector.prototype.Moffat4;
    P.maxPSFFits = 8000;

    if (!P.executeGlobal()) {
        throw new Error("SubframeSelector execution failed for: " + imagePath);
    }

    console.noteln("SubframeSelector executed successfully.");

    if (P.measurements.length > 0) {
        let measurement = P.measurements[0];
        console.writeln(
            "FWHM: " + measurement[5] +
            ", Eccentricity: " + measurement[6] +
            ", Stars Detected: " + measurement[14]
        );
        return {
            FWHM: measurement[5],
            Eccentricity: measurement[6],
            StarsDetected: measurement[14],
            ImageName: view.fullId,
        };
    } else {
        throw new Error("No valid measurements found in: " + imagePath);
    }
}

AstroImageDetailDialog.prototype.measurePSF = function (view) {
    console.noteln("Starting PSF measurement...");

    let starsView = this.findStarsImage(view);
    if (starsView) {
        console.noteln("Using _stars image for PSF measurement.");
        let starsTempFilePath = saveViewAsTemporaryFile(starsView);
        if (!starsTempFilePath) {
            console.warningln("Failed to save _stars image for PSF measurement.");
            return null;
        }
        let result = measureFWHM(starsTempFilePath, starsView);

        // ✅ Ensure file deletion safely
        if (File.exists(starsTempFilePath)) {
            try {
                File.remove(starsTempFilePath);
                console.noteln("✅ Deleted temp file:", starsTempFilePath);
            } catch (error) {
                console.warningln("❌ Failed to delete temp file:", starsTempFilePath, error.message);
            }
        }
        return result ? result.FWHM : null;
    }

    let tempFilePath = saveViewAsTemporaryFile(view);
    if (!tempFilePath) {
        console.warningln("❌ Temp file creation failed.");
        return null;
    }

    let result = measureFWHM(tempFilePath, view);

    // ✅ Ensure temp file deletion safely
    if (File.exists(tempFilePath)) {
        try {
            File.remove(tempFilePath);
            console.noteln("✅ Deleted temp file:", tempFilePath);
        } catch (error) {
            console.warningln("❌ Failed to delete temp file:", tempFilePath, error.message);
        }
    }

    return result ? result.FWHM : null;
};

AstroImageDetailDialog.prototype.findStarsImage = function (view) {
    let baseName = view.fullId;

    // List of possible star mask names, prioritized
    let possibleNames = [
        baseName + "_stars",  // ✅ Preferred (e.g., from StarXTerminator)
        baseName + "_star_mask", // ✅ Alternative suffix
        baseName + "star_mask",  // ✅ Alternative suffix
        "star_mask"          // ✅ Fallback option (StarNet++ output)
    ];

    console.noteln("🔍 Searching for a stars-only image associated with:", baseName);

    let windows = ImageWindow.windows;
    for (let win of windows) {
        let winName = win.mainView.fullId;

        // ✅ Improved detection: Use "startsWith" to catch variations
        for (let possibleName of possibleNames) {
            if (winName.startsWith(possibleName)) {
                console.noteln("✅ Found stars-only image:", winName);
                return win.mainView;
            }
        }
    }

    console.warningln("❌ No stars-only image found (_stars, _mask, or stars_mask).");
    return null;
};

AstroImageDetailDialog.prototype.applyBlurXTerminator = function (view, psfDiameter) {
   console.noteln("Executing BlurXTerminator on view: " + view.fullId);

   let P = new BlurXTerminator();
   P.ai_file = BLURXTERMINATOR_AI_FILE; // Use platform-specific macro
   P.correct_only = false;
   P.correct_first = false;
   P.nonstellar_then_stellar = false;
   P.lum_only = false;
   P.sharpen_stars = 0.50; // Default star sharpening
   P.adjust_halos = 0.00;
   P.sharpen_nonstellar = AstroImageDetailParameters.sharpenNonStellar; // Use GUI slider value

   // Set PSF diameter (capped at 8)
   P.auto_nonstellar_psf = false;
   P.nonstellar_psf_diameter = Math.min(psfDiameter, 8);
   console.noteln("BlurXTerminator PSF Diameter set to: " + P.nonstellar_psf_diameter.toFixed(2));

   try {
      if (!P.executeOn(view)) {
         throw new Error("BlurXTerminator execution failed.");
      }
      console.noteln("BlurXTerminator applied successfully.");
   } catch (error) {
      console.warningln("Error executing BlurXTerminator: " + error.message);
      new MessageBox("BlurXTerminator failed to execute.", "Error", StdIcon_Error, StdButton_Ok).execute();
   }
};

AstroImageDetailDialog.prototype.removeStars = function (view) {
    console.noteln("🔍 Checking which star removal method to use...");
    console.noteln("Current setting:", AstroImageDetailParameters.useStarXTerminator ? "StarXTerminator" : "StarNet++");

    if (AstroImageDetailParameters.useStarXTerminator) {
        console.noteln("✅ Using StarXTerminator for star removal...");
        return this.applyStarXTerminator(view);
    } else {
        console.noteln("✅ Using StarNet++ for star removal...");
        return this.applyStarNet(view);
    }
};

AstroImageDetailDialog.prototype.applyStarXTerminator = function (view) {
    console.noteln("Attempting to remove stars using StarXTerminator...");

    let P = new StarXTerminator();
    P.ai_file = STARXTERMINATOR_AI_FILE;
    P.stars = true;
    P.unscreen = false;
    P.overlap = 0.20;

    try {
        let success = P.executeOn(view);
        if (!success) {
            throw new Error("❌ StarXTerminator execution returned false.");
        }

        console.noteln("✅ StarXTerminator applied successfully.");

        // Find the newly created stars image
        let starsView = this.findStarsImage(view);
        if (!starsView) {
            console.warningln("🚨 StarXTerminator executed, but stars image not found.");
            return null;
        }
        return starsView;

    } catch (error) {
        console.warningln("🚨 StarXTerminator failed: " + error.message);
        return null;
    }
};

AstroImageDetailDialog.prototype.applyStarNet = function (view) {
    console.noteln("Attempting to remove stars using StarNet++...");

    let P = new StarNet2();
    P.stride = StarNet2.prototype.defStride;
    P.mask = true;  // Using a star mask
    P.linear = true;
    P.upsample = false;
    P.shadows_clipping = -2.80;
    P.target_background = 0.25;

    try {
        if (!P.executeOn(view)) {
            throw new Error("❌ StarNet++ execution failed.");
        }

        console.noteln("✅ StarNet++ applied successfully.");

        // Rename the processed view for clarity
        let starlessWindow = view.window;
        let newStarlessName = view.fullId + "_starless";
        console.noteln("🔄 Renaming StarNet++ processed image to:", newStarlessName);
        starlessWindow.mainView.id = newStarlessName;

        return starlessWindow.mainView;
    } catch (error) {
        console.warningln("❌ StarNet++ failed: " + error.message);
        return null;
    }
};

AstroImageDetailDialog.prototype.restoreStars = function (dsoView) {
    console.noteln("🔹 Restoring stars with PixelMath...");

    if (!dsoView) {
        console.warningln("❌ Error: Starless image not found.");
        return false;
    }

    // **Retrieve the stars image before applying PixelMath**
    let starsView = this.findStarsImage(dsoView);
    if (!starsView) {
        console.warningln("❌ No stars image found. Cannot proceed.");
        return false;
    }

    let P = new PixelMath();
    let starsImageId = starsView.id;  // Get actual stars image ID

    // ✅ Dynamically set PixelMath formula based on detected stars image
    let pixelMathExpression = "$T + " + starsImageId;
    console.noteln("✅ Applying PixelMath: " + pixelMathExpression);

    P.expression = pixelMathExpression;
    P.useSingleExpression = true;
    P.createNewImage = false;
    P.showNewImage = true;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    if (!P.executeOn(dsoView)) {
        console.warningln("🚨 PixelMath execution failed.");
        return false;
    }

    console.noteln("✅ Stars successfully restored.");

    // ✅ Close the stars-only image after recombination
    let starsWindow = starsView.window;
    if (starsWindow && !starsWindow.isNull) {
        console.noteln("❌ Closing stars-only image:", starsWindow.mainView.id);
        starsWindow.forceClose();
    }

    return true;
};

AstroImageDetailDialog.prototype.createTemporaryImage = function(selectedImage) {
   let window = new ImageWindow(
      selectedImage.width,
      selectedImage.height,
      selectedImage.numberOfChannels,
      selectedImage.bitsPerSample,
      selectedImage.isReal,
      selectedImage.isColor
   );

   window.mainView.beginProcess();
   window.mainView.image.assign(selectedImage);
   window.mainView.endProcess();

   var P = new IntegerResample;
   switch (this.zoomComboBox.currentItem) {
      case 0:
         P.zoomFactor = -1;
         break;
      case 1:
         P.zoomFactor = -2;
         break;
      case 2:
         P.zoomFactor = -4;
         break;
      case 3:
         P.zoomFactor = -8;
         break;
      case 4:
         const previewWidth = this.previewControl.width;
         const widthScale = Math.floor(selectedImage.width / previewWidth);
         P.zoomFactor = -Math.max(widthScale, 1);
         break;
      default:
         P.zoomFactor = -2;
         break;
   }

   P.executeOn(window.mainView);

   let resizedImage = new Image(window.mainView.image);

   if (resizedImage.width > 0 && resizedImage.height > 0) {
      this.previewControl.displayImage = resizedImage;
      this.previewControl.doUpdateImage(resizedImage);
      this.previewControl.initScrollBars();
   } else {
      console.error("Resized image has invalid dimensions.");
   }

   window.forceClose();

   return resizedImage;
};

// Function to check if the view is grayscale
function isGrayscale(view) {
   return !view.image.isColor;
}

function run() {
    if (!AstroImageDetailParameters.targetView) {
        console.warningln("❌ No target view is specified. Cannot proceed.");
        cleanupTempFiles();
        return;
    }

    console.noteln("🔍 Target view detected: " + AstroImageDetailParameters.targetView.fullId);

    let dialog = new AstroImageDetailDialog();
    let psfDiameter = null; // ✅ Declared only once, like in refreshPreview
    let starsView = null;
    let usingStarsImage = false;

    // ✅ Step 1: Search for an existing stars-only image (_stars, _star_mask)
    if (AstroImageDetailParameters.enableBlurXTerminator) {
        console.noteln("🟢 BlurXTerminator is enabled. Checking for stars-only image...");

        starsView = dialog.findStarsImage(AstroImageDetailParameters.targetView);
        usingStarsImage = starsView !== null;

        if (usingStarsImage) {
            console.noteln("✅ Using stars-only image for PSF measurement.");
        } else {
            console.noteln("❌ No stars-only image found. Measuring PSF from main image.");
        }

        let psfSourceView = usingStarsImage ? starsView : AstroImageDetailParameters.targetView;
        psfDiameter = dialog.measurePSF(psfSourceView);

        if (psfDiameter === null) {
            console.warningln("🚨 No stars detected. Cannot proceed.");
            new MessageBox("No stars detected and no _stars image found.", "Error", StdIcon_Error, StdButton_Ok).execute();
            cleanupTempFiles();
            return;
        }
    }

    // ✅ Step 2: If no stars-only image was found, extract stars from the target image
    if (AstroImageDetailParameters.enableBlurXTerminator && !starsView) {
        console.noteln("❌ No pre-existing stars image found. Removing stars from target image...");
        starsView = dialog.removeStars(AstroImageDetailParameters.targetView);

        if (!starsView) {
            console.warningln("🚨 Star removal failed. Cannot proceed.");
            new MessageBox("Star removal failed.", "Error", StdIcon_Error, StdButton_Ok).execute();
            cleanupTempFiles();
            return;
        }
    }

    // ✅ Step 3: Apply BlurXTerminator with measured PSF
    if (AstroImageDetailParameters.enableBlurXTerminator) {
        console.noteln("🟢 Applying BlurXTerminator...");
        psfDiameter = Math.min(psfDiameter, 8);
        dialog.applyBlurXTerminator(AstroImageDetailParameters.targetView, psfDiameter);
    } else {
        console.noteln("🔵 Using default sharpening workflow (MLT and MMT).");

        if (AstroImageDetailParameters.LargeScale > 0) {
            console.noteln("🔵 Applying MLT (LargeScale =", AstroImageDetailParameters.LargeScale, ")");
            applyMLT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.LargeScale);
        }

        if (AstroImageDetailParameters.SmallScale > 0) {
            console.noteln("🔵 Applying MMT (SmallScale =", AstroImageDetailParameters.SmallScale, ")");
            applyMMT(AstroImageDetailParameters.targetView, AstroImageDetailParameters.SmallScale);
        }
    }

    // ✅ Step 4: Apply NoiseXTerminator if enabled
    if (AstroImageDetailParameters.applyNoiseXTerminator) {
        console.noteln("✅ Applying NoiseXTerminator...");
        applyNoiseXTerminator(AstroImageDetailParameters.targetView, AstroImageDetailParameters.denoise);
    } else {
        console.noteln("🚫 NoiseXTerminator not applied (checkbox is unchecked).");
    }

    // ✅ Step 5: **Only recombine stars if BlurXTerminator was applied AND a stars image did NOT already exist**
if (AstroImageDetailParameters.enableBlurXTerminator && !usingStarsImage) {
    console.noteln("🔹 No pre-existing stars image detected. Recombining extracted stars...");

    if (!dialog.restoreStars(AstroImageDetailParameters.targetView)) {
        console.warningln("❌ Star restoration failed. Cannot proceed.");
        new MessageBox("Star restoration failed.", "Error", StdIcon_Error, StdButton_Ok).execute();
        cleanupTempFiles();
        return;
    }

    console.noteln("✅ Star recombination completed successfully!");
} else {
    console.noteln("✅ A pre-existing stars image was found. Skipping star recombination.");
}

    cleanupTempFiles();
};

// Main execution logic
function main() {
   if (Parameters.isGlobalTarget) {
      // If the new instance is double-clicked, open the dialog
      if (Parameters.has("LargeScale") || Parameters.has("SmallScale") || Parameters.has("showPreview")) {
         // Load parameters if they exist
         console.noteln("Double-click detected: Loading parameters and opening Astro Image Detail GUI...");
         AstroImageDetailParameters.load();
      } else {
         console.noteln("Double-click detected: No parameters found. Opening Astro Image Detail GUI...");
      }
      let dialog = new AstroImageDetailDialog();
      dialog.execute();
      return;
   }

    if (Parameters.isViewTarget) {
      // If the new instance is dropped on a view, run the script on the target view
      console.noteln("New instance dragged onto a view: Running script...");
      AstroImageDetailParameters.load();
      if (!Parameters.targetView.isNull) {
         AstroImageDetailParameters.targetView = Parameters.targetView;
         run(); // Execute the script with the current parameters
      } else {
         console.warningln("The target view is invalid.");
      }
      return;
   }

    // For direct execution, open the dialog
   let dialog = new AstroImageDetailDialog();
   dialog.execute();
}

main();
