#feature-id   AstroImagePrimer : HLP > Astro Image Primer
#feature-info This script performs the beginning stages of image correction.

// Astro Image Primer Script

#include <pjsr/TextAlign.jsh>
#include <pjsr/Sizer.jsh>

var MIN_GUI_WIDTH = 1300;  // GUI width
var MIN_GUI_HEIGHT = 1100; // GUI height

var generatedViews = []; // Track all generated view IDs
let channelMapping = []; // Initialize channelMapping as an empty array at the top of the script


// Function to apply Linear Fit
function applyLinearFit(referenceViewId, targetViewId) {
    var targetView = View.viewById(targetViewId);
    if (targetView == null) {
        Console.warningln("Target view not found: " + targetViewId);
        return; // Skip this target view
    }

    var P = new LinearFit;
    P.referenceViewId = referenceViewId;
    P.rejectLow = 0.0;
    P.rejectHigh = 0.92;

    if (!P.executeOn(targetView)) {
        Console.warningln("Linear Fit failed on target: " + targetViewId);
    } else {
        Console.writeln("Linear Fit applied to " + targetViewId + " using reference " + referenceViewId);
    }
}

// Function to calculate mean value
function calculateMean(viewId) {
    let view = View.viewById(viewId);

    // Fallback: If the view is not found, check for "_registered" suffix
    if (!view) {
        Console.warningln("View not found: " + viewId + ". Trying '_registered' version.");
        view = View.viewById(viewId + "_registered");
    }

    if (view) {
        let stats = new ImageStatistics();
        stats.generate(view.image);
        return stats.mean;
    }

    Console.warningln("Failed to calculate mean for: " + viewId);
    return 0; // Default to 0 if view is not found
}

// Function to perform Star Alignment
function performStarAlignment(dialog, channels) {
    Console.writeln("Performing Star Alignment...");

    if (!channels || channels.length !== 3) {
        throw new Error("Invalid channels array passed to performStarAlignment.");
    }

    let meanValues = channels.map(calculateMean);
    let sortedMeans = meanValues.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]);
    let referenceIndex = sortedMeans[1][1];
    let referenceChannel = channels[referenceIndex];
    let targetChannels = channels.filter((_, index) => index !== referenceIndex);

    Console.writeln("Reference channel for Star Alignment: " + referenceChannel);
    Console.writeln("Target channels for Star Alignment: " + targetChannels.join(", "));

    let P = new StarAlignment();
    P.referenceImage = referenceChannel;
    P.referenceIsFile = false;
    P.targets = targetChannels.map((channelId) => [true, false, channelId]);
    P.outputPostfix = "_registered";

    // Execute StarAlignment
    if (!P.executeGlobal()) {
        Console.warningln("Star Alignment failed.");
        return channels; // Return original channels on failure
    }

    // Update mapping for registered images
    return channels.map((channelId, index) => {
        if (index === referenceIndex) {
            return channelId; // Keep reference channel as is
        }
        let registeredId = channelId + "_registered";
        let view = View.viewById(registeredId);
        if (view) {
            generatedViews.push(registeredId);
            return registeredId;
        } else {
            Console.warningln("Registered view not found: " + registeredId);
            return channelId; // Fallback to original ID
        }
    });
}

// Function to apply BlurXTerminator
function applyBlurXTerminator(viewId) {
    var view = View.viewById(viewId);
    if (view != null) {
        var P = new BlurXTerminator;
        P.executeOn(view);
        Console.writeln("BlurXTerminator applied to " + viewId);
    } else {
        Console.warningln("View not found for BlurXTerminator: " + viewId);
    }
}

// Function to combine channels into an RGB image
function combineChannelsWithLRGB(redChannel, greenChannel, blueChannel) {
    var P = new ChannelCombination;
    P.colorSpace = ChannelCombination.prototype.RGB;
    P.channels = [
        [true, redChannel], // Red
        [true, greenChannel], // Green
        [true, blueChannel] // Blue
    ];
    P.executeGlobal();

    // Rename the combined image
    var combinedView = ImageWindow.activeWindow;
    if (combinedView) {
        combinedView.mainView.id = "AstroImagePrimer";
        Console.writeln("Combined image named 'AstroImagePrimer'.");
    } else {
        Console.warningln("Failed to name combined image.");
    }
}

// Main workflow
function executeWorkflow(dialog) {
    var selectedViewId = dialog.viewList.currentView.id;
    var selectedView = View.viewById(selectedViewId);

    if (!selectedView) {
        Console.warningln("No view selected for processing.");
        return;
    }

    Console.writeln("Workflow starting...");
    var extractedChannels;

    // Extract or select channels
    if (dialog.useIndividualChannelsCheckBox.checked) {
        channelMapping = [
            { role: "R", id: dialog.redChannelDropdown.currentView.id },
            { role: "G", id: dialog.greenChannelDropdown.currentView.id },
            { role: "B", id: dialog.blueChannelDropdown.currentView.id }
        ];

        // Map channel IDs to extractedChannels
        extractedChannels = channelMapping.map((channel) => channel.id);

        if (dialog.starAlignmentCheckBox.checked) {
            extractedChannels = performStarAlignment(dialog, extractedChannels);
            // Update channelMapping with registered IDs
            channelMapping = channelMapping.map((channel, index) => ({
                role: channel.role,
                id: extractedChannels[index]
            }));
        }
    } else {
        // Handle combined image
        var P = new ChannelExtraction;
        P.colorSpace = ChannelExtraction.prototype.RGB;
        P.channels = [[true, ""], [true, ""], [true, ""]];
        P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
        P.inheritAstrometricSolution = true;
        P.executeOn(selectedView);

        extractedChannels = [
            selectedViewId + "_R",
            selectedViewId + "_G",
            selectedViewId + "_B"
        ];

        if (Array.isArray(extractedChannels) && extractedChannels.length > 0) {
            extractedChannels.forEach(function (channel) {
                generatedViews.push(channel);
            });
        } else {
            Console.warningln("No extracted channels found to push to generatedViews.");
        }

        if (dialog.starAlignmentCheckBox.checked) {
            extractedChannels = performStarAlignment(dialog, extractedChannels);
        }

        // Create a channel mapping for the extracted channels
        channelMapping = [
            { role: "R", id: extractedChannels[0] },
            { role: "G", id: extractedChannels[1] },
            { role: "B", id: extractedChannels[2] }
        ];
    }

    // Calculate mean values
    var meanValues = extractedChannels.map(calculateMean);
    var scaledMeanValues = meanValues.map(function (mean) {
        return Math.round(mean * 65535); // Scale to 16-bit range
    });

    // Determine reference channel
    var referenceIndex;
    if (dialog.referenceMeanComboBox.currentItem == 0) {
        referenceIndex = meanValues.indexOf(Math.max.apply(null, meanValues)); // Highest mean
    } else if (dialog.referenceMeanComboBox.currentItem == 1) {
        var sortedIndices = meanValues.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]);
        referenceIndex = sortedIndices[1][1]; // Middle mean
    } else if (dialog.referenceMeanComboBox.currentItem == 2) {
        referenceIndex = meanValues.indexOf(Math.min.apply(null, meanValues)); // Lowest mean
    }

    var referenceChannel = extractedChannels[referenceIndex];
    var targetChannels = extractedChannels.filter(function (_, index) {
        return index !== referenceIndex;
    });

    Console.writeln("Reference channel for Linear Fit: " + referenceChannel);

    // Update GUI with mean values and reference channel
    var scaledMeans = channelMapping.map((channel) => ({
        role: channel.role,
        mean: Math.round(calculateMean(channel.id) * 65535)
    }));

    dialog.meanValuesLabel.text = "Channel Mean Values (16-bit):\n" +
    scaledMeans.map((channel) => {
        // Assign explicit names for each role
        let roleName = {
            "R": "Red / Ha",
            "G": "Green / Sii",
            "B": "Blue / Oiii"
        }[channel.role] || channel.role; // Default to role if not mapped

        return roleName + ": " + channel.mean;
    }).join("\n") +
    "\nReference Channel: " + referenceChannel;

    // Apply Linear Fit
    targetChannels.forEach(function (targetChannel) {
        applyLinearFit(referenceChannel, targetChannel);
    });

    // Rename channels or combine based on user preference
    if (dialog.keepChannelsSeparatedCheckBox.checked) {
        Console.writeln("Keep Channels Separated is checked. Renaming channels...");
        extractedChannels.forEach(function (channelId, index) {
            var channelView = View.viewById(channelId);
            if (channelView) {
                var newName;
                if (index === 0) newName = "AstroImagePrimer_R_Ha";
                else if (index === 1) newName = "AstroImagePrimer_G_Sii";
                else if (index === 2) newName = "AstroImagePrimer_B_Oiii";

                // Rename the view
                channelView.window.mainView.id = newName;
                Console.writeln("Renamed channel: " + channelId + " to " + newName);
            }
        });

        // Apply BlurXTerminator to renamed channels if Star Correction is checked
        if (dialog.starCorrectionCheckBox.checked) {
            Console.writeln("Applying BlurXTerminator to separated channels...");
            ["AstroImagePrimer_R_Ha", "AstroImagePrimer_G_Sii", "AstroImagePrimer_B_Oiii"].forEach(applyBlurXTerminator);
        }
    } else {
        // Combine channels if required
        combineChannelsWithLRGB(extractedChannels[0], extractedChannels[1], extractedChannels[2]);

        // Apply BlurXTerminator to combined image if Star Correction is checked
        if (dialog.starCorrectionCheckBox.checked) {
            Console.writeln("Applying BlurXTerminator to combined image...");
            applyBlurXTerminator("AstroImagePrimer");
        }
    }

    // Cleanup logic
    if (!dialog.keepChannelsSeparatedCheckBox.checked) {
        Console.writeln("Closing generated windows...");
        generatedViews.forEach(function (viewId) {
            var view = View.viewById(viewId);
            if (view) {
                ImageWindow.windowById(viewId).forceClose(); // Proper closure
                Console.writeln("Closed view: " + viewId);
            }
        });
    }

    Console.writeln("Workflow complete.");
}

// Main dialog for the script GUI
function LinearFitDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 4;
    this.scaledMinWidth = MIN_GUI_WIDTH;
    this.scaledMinHeight = MIN_GUI_HEIGHT;

    this.titleLabel = new Label(this);
    this.titleLabel.text = "Astro Image Primer";
    this.titleLabel.textAlignment = TextAlign_Center;
    this.titleLabel.font = new Font("SansSerif", 20);
    this.sizer.add(this.titleLabel);
    this.sizer.addSpacing(8);

    this.instructionGroupBox = new GroupBox(this);
    this.instructionGroupBox.title = "Instructions";
    this.instructionGroupBox.sizer = new VerticalSizer;
    this.instructionGroupBox.sizer.margin = 6;
    this.instructionGroupBox.sizer.spacing = 4;

    this.instructionLabel = new Label(this.instructionGroupBox);
    this.instructionLabel.text = "This script performs initial correction steps on an image.\n" +
                                 "Choose either a combined image or individual channels by toggling the Use Individual Channels option.\n" +
                                 "Insert your combined image or individual channels.\n" +
                                 "Select the options you want to perform and click execute.\n\n" +
                                 "Options:\n" +
                                 "- Star Correction: Applies BlurXTerminator Correct Only to improve star quality (BlurXterminator Required).\n" +
                                 "- Keep Channels Separated: Keeps extracted channels open after Linear Fit without combining them.\n" +
                                 "- Use Individual Channels: Allows manual selection of color channels.\n" +
                                 "- Star Alignment: Performs the Star Alignment process to properly align your images. (Highly Recommended for Mono Images)\n\n" +
                                 "Click Execute to run the script.\n\n" +
                                 "Written by Tony De Nardo.";
    this.instructionLabel.textAlignment = TextAlign_Center;
    this.instructionLabel.font = new Font("SansSerif", 12);
    this.instructionGroupBox.sizer.add(this.instructionLabel);

    this.sizer.add(this.instructionGroupBox);
    this.sizer.addSpacing(8);

    this.optionsGroupBox = new GroupBox(this);
    this.optionsGroupBox.title = "Options";
    this.optionsGroupBox.sizer = new VerticalSizer;
    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 4;

    this.useIndividualChannelsCheckBox = new CheckBox(this.optionsGroupBox);
    this.useIndividualChannelsCheckBox.text = "Use Individual Channels";
    this.optionsGroupBox.sizer.add(this.useIndividualChannelsCheckBox);

    this.starCorrectionCheckBox = new CheckBox(this.optionsGroupBox);
    this.starCorrectionCheckBox.text = "Star Correction (BlurXterminator Required)";
    this.optionsGroupBox.sizer.add(this.starCorrectionCheckBox);

    this.keepChannelsSeparatedCheckBox = new CheckBox(this.optionsGroupBox);
    this.keepChannelsSeparatedCheckBox.text = "Keep Channels Separated";
    this.optionsGroupBox.sizer.add(this.keepChannelsSeparatedCheckBox);

    this.starAlignmentCheckBox = new CheckBox(this.optionsGroupBox);
    this.starAlignmentCheckBox.text = "Star Alignment (Recommended for Mono Images)";
    this.optionsGroupBox.sizer.add(this.starAlignmentCheckBox);

    this.sizer.add(this.optionsGroupBox);
    this.sizer.addSpacing(8);

    this.viewLabel = new Label(this);
    this.viewLabel.text = "Select Image";
    this.viewLabel.textAlignment = TextAlign_Left;

    this.viewList = new ViewList(this);
    this.viewList.getAll();

    this.viewSectionSizer = new VerticalSizer;
    this.viewSectionSizer.spacing = 2;
    this.viewSectionSizer.add(this.viewLabel);
    this.viewSectionSizer.addSpacing(4);
    this.viewSectionSizer.add(this.viewList);
    this.viewSectionSizer.addStretch();

    this.sizer.add(this.viewSectionSizer);
    this.sizer.addSpacing(8);

    // Select Channels Section
    this.channelsLabel = new Label(this);
    this.channelsLabel.text = "Select Channels";
    this.channelsLabel.textAlignment = TextAlign_Left;

    // Red Channel Label and Dropdown
    this.redChannelLabel = new Label(this);
    this.redChannelLabel.text = "Red / Ha";
    this.redChannelLabel.textAlignment = TextAlign_Left;

    this.redChannelDropdown = new ViewList(this);
    this.redChannelDropdown.getAll();
    this.redChannelDropdown.enabled = false;

    // Green Channel Label and Dropdown
    this.greenChannelLabel = new Label(this);
    this.greenChannelLabel.text = "Green / Sii";
    this.greenChannelLabel.textAlignment = TextAlign_Left;

    this.greenChannelDropdown = new ViewList(this);
    this.greenChannelDropdown.getAll();
    this.greenChannelDropdown.enabled = false;

    // Blue Channel Label and Dropdown
    this.blueChannelLabel = new Label(this);
    this.blueChannelLabel.text = "Blue / Oiii";
    this.blueChannelLabel.textAlignment = TextAlign_Left;

    this.blueChannelDropdown = new ViewList(this);
    this.blueChannelDropdown.getAll();
    this.blueChannelDropdown.enabled = false;

    // Layout for Channels Section
    this.channelsSectionSizer = new VerticalSizer;
    this.channelsSectionSizer.spacing = 4;
    this.channelsSectionSizer.add(this.channelsLabel);
    this.channelsSectionSizer.addSpacing(6);
    this.channelsSectionSizer.add(this.redChannelLabel);
    this.channelsSectionSizer.add(this.redChannelDropdown);
    this.channelsSectionSizer.addSpacing(4);
    this.channelsSectionSizer.add(this.greenChannelLabel);
    this.channelsSectionSizer.add(this.greenChannelDropdown);
    this.channelsSectionSizer.addSpacing(4);
    this.channelsSectionSizer.add(this.blueChannelLabel);
    this.channelsSectionSizer.add(this.blueChannelDropdown);
    this.channelsSectionSizer.addStretch();

    this.sizer.add(this.channelsSectionSizer);
    this.sizer.addSpacing(8);

    this.referenceLabel = new Label(this);
    this.referenceLabel.text = "Select Reference Type";
    this.referenceLabel.textAlignment = TextAlign_Left;

    this.referenceMeanComboBox = new ComboBox(this);
    this.referenceMeanComboBox.addItem("Highest Mean");
    this.referenceMeanComboBox.addItem("Middle Mean");
    this.referenceMeanComboBox.addItem("Lowest Mean");

    this.referenceSectionSizer = new VerticalSizer;
    this.referenceSectionSizer.spacing = 2;
    this.referenceSectionSizer.add(this.referenceLabel);
    this.referenceSectionSizer.addSpacing(4);
    this.referenceSectionSizer.add(this.referenceMeanComboBox);
    this.referenceSectionSizer.addStretch();

    this.sizer.add(this.referenceSectionSizer);
    this.sizer.addSpacing(8);

    this.meanValuesContainer = new Control(this);
    this.meanValuesContainer.setScaledMinSize(200, 100);
    this.meanValuesContainer.styleSheet = "background-color: white; border: 1px solid gray; padding: 6px;";

    this.meanValuesLabel = new Label(this.meanValuesContainer);
    this.meanValuesLabel.text = "Channel Mean Values: R: -, G: -, B: -\nSelected Reference: None";
    this.meanValuesLabel.textAlignment = TextAlign_Left;

    // Adjust font size for better readability
    this.meanValuesLabel.font = new Font("SansSerif", 12);

    this.meanValuesContainer.sizer = new VerticalSizer;
    this.meanValuesContainer.sizer.margin = 6;
    this.meanValuesContainer.sizer.add(this.meanValuesLabel);

    this.sizer.add(this.meanValuesContainer);
    this.sizer.addSpacing(8);

    this.useIndividualChannelsCheckBox.onCheck = function (checked) {
        this.viewList.enabled = !checked;
        this.redChannelDropdown.enabled = checked;
        this.greenChannelDropdown.enabled = checked;
        this.blueChannelDropdown.enabled = checked;
    }.bind(this);

    this.execButton = new PushButton(this);
    this.execButton.text = "Execute";
    this.execButton.onClick = function () {
        executeWorkflow(this);
        Console.hide();
    }.bind(this);

    this.sizer.add(this.execButton);
    this.windowTitle = "Astro Image Primer";
}
LinearFitDialog.prototype = new Dialog;

// Main function
function main() {
    var dialog = new LinearFitDialog();
    dialog.execute();
}

main();

