#feature-id   AstroImagePrimer : HLP > Astro Image Primer
#feature-info A script to perform the intial correction phase of an image.

#include <pjsr/TextAlign.jsh>
#include <pjsr/Sizer.jsh>

// Global parameters
var referenceViewId = ""; // Reference channel view ID

// Function to apply Linear Fit
function applyLinearFit(referenceViewId, targetViewId) {
  var targetView = View.viewById(targetViewId);
  if (targetView != null) {
    var P = new LinearFit;
    P.referenceViewId = referenceViewId;
    P.rejectLow = 0.0;
    P.rejectHigh = 0.92;
    P.executeOn(targetView);
  } else {
    Console.warningln("Target view not found: " + targetViewId);
  }
}

// Function to extract RGB channels
function extractChannels(view) {
  var P = new ChannelExtraction;
  P.colorSpace = ChannelExtraction.prototype.RGB;
  P.channels = [
    [true, ""],
    [true, ""],
    [true, ""]
  ];
  P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
  P.inheritAstrometricSolution = true;
  P.executeOn(view);
}

// Function to combine RGB channels
function combineChannels(redViewId, greenViewId, blueViewId, targetViewId) {
  var redView = View.viewById(redViewId);
  var greenView = View.viewById(greenViewId);
  var blueView = View.viewById(blueViewId);
  var targetView = View.viewById(targetViewId);

  if (redView != null && greenView != null && blueView != null) {
    if (targetView == null) {
      // Create a new image window if the target view doesn't exist
      var width = redView.image.width;
      var height = redView.image.height;
      var targetWindow = new ImageWindow(width, height, 3, 32, true, false, targetViewId);
      targetView = targetWindow.mainView;
      targetWindow.show();
    }

    var P = new ChannelCombination;
    P.colorSpace = ChannelCombination.prototype.RGB;
    P.channels = [
      [true, redView.id],
      [true, greenView.id],
      [true, blueView.id]
    ];
    P.inheritAstrometricSolution = true;
    P.executeOn(targetView);
  } else {
    Console.warningln("One or more views not found for channel combination.");
  }
}

// Function to calculate mean values for channels
function calculateMean(viewId) {
  var view = View.viewById(viewId);
  if (view != null) {
    var mean = view.computeOrFetchProperty("Mean");
    return mean.at(0); // Assuming single-channel or grayscale images for simplicity
  }
  return 0;
}

// Dialog for user interaction
function LinearFitDialog() {
  this.__base__ = Dialog;
  this.__base__();

  // Create the main sizer for the dialog layout
  this.sizer = new VerticalSizer;
  this.sizer.margin = 6;
  this.sizer.spacing = 4;
  this.scaledMinWidth = 600;

  // Title label (corrected version)
  this.titleLabel = new Label(this);
  this.titleLabel.text = "Astro Image Primer";
  this.titleLabel.textAlignment = TextAlign_Center;
  this.titleLabel.font = new Font("SansSerif", 20);
  this.sizer.add(this.titleLabel);
  this.sizer.addSpacing(8);

  // Instruction group box (corrected version)
  this.instructionGroupBox = new GroupBox(this);
  this.instructionGroupBox.title = "Instructions";
  this.instructionGroupBox.sizer = new VerticalSizer;
  this.instructionGroupBox.sizer.margin = 6;
  this.instructionGroupBox.sizer.spacing = 4;

  // Instruction label (now properly nested in the instruction group box)
  this.instructionLabel = new Label(this.instructionGroupBox);
  this.instructionLabel.text = "This script provides a way to perform the initial correction steps to your image.\n" +
                               "Select the image you want to work on and select if you want to use the highest, middle or lowest mean value as a reference type\n\n" +
                               "Options:\n" +
                               "- Select Star Correction to perform the initial correction to the stars. (BlurXterminator is required in order for this option to function).\n\n" +
                               "- Select Keep Channels Separated if you do not want the script to recombine the channels after Linear Fit.\n\n" +
                               "Click Execute to run the script.\n\n" +
                               "Important Note:\n" +
                               "If executing on an auto stretched image, please delete the auto stretch after the script runs\n" +
                               "and repply the the auto stretch for proper viewing.\n\n" +
                               "Written by Tony De Nardo";
  this.instructionLabel.textAlignment = TextAlign_Center;
  this.instructionGroupBox.sizer.add(this.instructionLabel);

  // Add the instruction group box to the main sizer
  this.sizer.add(this.instructionGroupBox);
  this.sizer.addSpacing(8);

  // Options section with checkboxes
  this.optionsGroupBox = new GroupBox(this);
  this.optionsGroupBox.title = "Options";
  this.optionsGroupBox.sizer = new HorizontalSizer;
  this.optionsGroupBox.sizer.margin = 6;
  this.optionsGroupBox.sizer.spacing = 4;

  this.starCorrectionCheckBox = new CheckBox(this.optionsGroupBox);
  this.starCorrectionCheckBox.text = "Star Correction";
  this.optionsGroupBox.sizer.add(this.starCorrectionCheckBox);

  this.keepChannelsSeparatedCheckBox = new CheckBox(this.optionsGroupBox);
  this.keepChannelsSeparatedCheckBox.text = "Keep Channels Separated";
  this.optionsGroupBox.sizer.add(this.keepChannelsSeparatedCheckBox);

  this.sizer.add(this.optionsGroupBox);
  this.sizer.addSpacing(8);

  // Vertical sizer for selecting the active view (corrected version)
  this.viewLabel = new Label(this);
  this.viewLabel.text = "Select Image";
  this.viewLabel.textAlignment = TextAlign_Left;

  this.viewList = new ViewList(this);
  this.viewList.getAll();
  this.viewList.adjustToContents = false;
  this.viewList.setFixedWidth(600);
  this.viewList.setScaledMinWidth(120);
  this.viewList.minWidth = 80;

  this.viewSectionSizer = new VerticalSizer;
  this.viewSectionSizer.spacing = 2;
  this.viewSectionSizer.add(this.viewLabel);
  this.viewSectionSizer.addSpacing(4);
  this.viewSectionSizer.add(this.viewList);
  this.viewSectionSizer.addStretch();

  this.sizer.add(this.viewSectionSizer);
  this.sizer.addSpacing(8);

  // Vertical sizer for selecting the reference type (corrected version)
  this.referenceLabel = new Label(this);
  this.referenceLabel.text = "Select Reference Type";
  this.referenceLabel.textAlignment = TextAlign_Left;

  this.referenceMeanComboBox = new ComboBox(this);
  this.referenceMeanComboBox.adjustToContents = false;
  this.referenceMeanComboBox.setFixedWidth(150);
  this.referenceMeanComboBox.setScaledMinWidth(120);
  this.referenceMeanComboBox.minWidth = 80;
  this.referenceMeanComboBox.addItem("Highest Mean");
  this.referenceMeanComboBox.addItem("Middle Mean");
  this.referenceMeanComboBox.addItem("Lowest Mean");

  this.referenceSectionSizer = new VerticalSizer;
  this.referenceSectionSizer.spacing = 2;
  this.referenceSectionSizer.add(this.referenceLabel);
  this.referenceSectionSizer.addSpacing(4);
  this.referenceSectionSizer.add(this.referenceMeanComboBox);
  this.referenceSectionSizer.addStretch();

  this.sizer.add(this.referenceSectionSizer);
  this.sizer.addSpacing(8);

  // Container for mean values with white background (corrected version)
  this.meanValuesContainer = new Control(this);
  this.meanValuesContainer.setScaledMinSize(200, 100);
  this.meanValuesContainer.styleSheet = "background-color: white; border: 1px solid gray; padding: 6px;";

  this.meanValuesLabel = new Label(this.meanValuesContainer);
  this.meanValuesLabel.text = "Channel Mean Values: R: -, G: -, B: -";
  this.meanValuesLabel.textAlignment = TextAlign_Left;
  this.meanValuesLabel.font = new Font("", 12);

  this.meanValuesContainer.sizer = new VerticalSizer;
  this.meanValuesContainer.sizer.margin = 6;
  this.meanValuesContainer.sizer.add(this.meanValuesLabel);

  this.sizer.add(this.meanValuesContainer);
  this.sizer.addSpacing(8);

  // Execute button to apply the Linear Fit (corrected version)
  this.execButton = new PushButton(this);
  this.execButton.text = "Execute";
  this.execButton.onClick = function () {
    var view = this.viewList.currentView;
    if (view != null) {
      // Apply StarXterminator correction if the option is checked
      if (this.starCorrectionCheckBox.checked) {
        var P = new BlurXTerminator;
        P.ai_file = "BlurXTerminator.4.pb";
        P.correct_only = true;
        P.correct_first = false;
        P.nonstellar_then_stellar = false;
        P.lum_only = false;
        P.sharpen_stars = 0.50;
        P.adjust_halos = 0.00;
        P.nonstellar_psf_diameter = 1.62;
        P.auto_nonstellar_psf = false;
        P.sharpen_nonstellar = 0.50;
        if (!P.executeOn(view)) {
          Console.warningln("BlurXTerminator correction failed.");
          Console.writeln("Ready."); // Ensure "Ready" is printed even if there is an error.
          return;
        }
        Console.writeln("BlurXTerminator correction applied.");
      }

      // Extract channels
      extractChannels(view);

      // Assuming the channels are named automatically with suffixes _R, _G, _B
      var redViewId = view.id + "_R";
      var greenViewId = view.id + "_G";
      var blueViewId = view.id + "_B";

      // Calculate mean values for the channels
      var means = [
        { id: redViewId, mean: calculateMean(redViewId) },
        { id: greenViewId, mean: calculateMean(greenViewId) },
        { id: blueViewId, mean: calculateMean(blueViewId) }
      ];

      // Update mean values label
      this.meanValuesLabel.text = "Channel Mean Values: R: " + (means[0].mean * 65535).toFixed(0) + ", G: " + (means[1].mean * 65535).toFixed(0) + ", B: " + (means[2].mean * 65535).toFixed(0);
      this.meanValuesLabel.font = new Font("", 12); // Set a slightly larger font size

      // Sort channels by mean value
      means.sort(function (a, b) { return a.mean - b.mean; });

      // Select reference channel based on user's choice
      var referenceChannel;
      switch (this.referenceMeanComboBox.currentItem) {
        case 0:
          referenceChannel = means[2].id; // Highest mean
          break;
        case 1:
          referenceChannel = means[1].id; // Middle mean
          break;
        case 2:
          referenceChannel = means[0].id; // Lowest mean
          break;
      }

      // Highlight the selected reference channel in the mean values label
      this.meanValuesLabel.text += " (Reference Used: " + referenceChannel.replace(view.id + "_", "") + ")";

      // Apply Linear Fit to the other channels using the selected reference
      if (redViewId !== referenceChannel) applyLinearFit(referenceChannel, redViewId);
      if (greenViewId !== referenceChannel) applyLinearFit(referenceChannel, greenViewId);
      if (blueViewId !== referenceChannel) applyLinearFit(referenceChannel, blueViewId);

      // Combine the channels back if "Keep Channels Separated" is not checked
      if (!this.keepChannelsSeparatedCheckBox.checked) {
        combineChannels(redViewId, greenViewId, blueViewId, view.id);

        // Close the extracted channel views
        var redView = View.viewById(redViewId);
        var greenView = View.viewById(greenViewId);
        var blueView = View.viewById(blueViewId);
        if (redView != null) redView.window.forceClose();
        if (greenView != null) greenView.window.forceClose();
        if (blueView != null) blueView.window.forceClose();
      }

      Console.writeln("Linear Fit applied with reference view: " + referenceChannel);
    } else {
      Console.warningln("No image selected.");
    }

    // Ensure "Ready" is printed at the end, no matter what
    Console.writeln("Ready.");
  }.bind(this);

  this.sizer.add(this.execButton);

  this.windowTitle = "Astro Image Primer";
}
LinearFitDialog.prototype = new Dialog;

function main() {
  // Run the dialog
  var dialog = new LinearFitDialog();
  dialog.execute();
}

main();
