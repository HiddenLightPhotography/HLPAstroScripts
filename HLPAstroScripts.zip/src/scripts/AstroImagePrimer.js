#feature-id   AstroImagePrimer : HLP > Astro Image Primer
#feature-info This script performs the beginning stages of image correction.

// Astro Image Primer Script

#include <pjsr/TextAlign.jsh>
#include <pjsr/Sizer.jsh>

#ifeq __PI_PLATFORM__ MACOSX
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.mlpackage"
#endif
#ifeq __PI_PLATFORM__ MSWINDOWS
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.pb"
#endif
#ifeq __PI_PLATFORM__ LINUX
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.pb"
#endif

var MIN_GUI_WIDTH = 1300;  // GUI width
var MIN_GUI_HEIGHT = 900; // GUI height

var generatedViews = []; // Track all generated view IDs
let channelMapping = []; // Initialize channelMapping as an empty array at the top of the script


// Function to apply Linear Fit
function applyLinearFit(referenceViewId, targetViewId) {
    var targetView = View.viewById(targetViewId);
    if (targetView == null) {
        Console.warningln("Target view not found: " + targetViewId);
        return; // Skip this target view
    }

    var P = new LinearFit;
    P.referenceViewId = referenceViewId;
    P.rejectLow = 0.0;
    P.rejectHigh = 0.92;

    if (!P.executeOn(targetView)) {
        Console.warningln("Linear Fit failed on target: " + targetViewId);
    } else {
        Console.writeln("Linear Fit applied to " + targetViewId + " using reference " + referenceViewId);
    }
}

// Function to calculate mean value
function calculateMean(viewId) {
    let view = View.viewById(viewId);

    if (!view) {
        Console.warningln("View not found: " + viewId + ". Trying '_registered' version.");
        view = View.viewById(viewId + "_registered");
    }

    if (view) {
        let stats = new ImageStatistics();
        stats.generate(view.image);
        Console.writeln("Mean value for " + viewId + ": " + stats.mean);
        return stats.mean;
    }

    Console.warningln("Failed to calculate mean for: " + viewId);
    return 0; // Default to 0 if view is not found
}

// Function to perform Star Alignment
function performStarAlignment(dialog, channels) {
    Console.writeln("Performing Star Alignment...");

    if (!channels || channels.length !== 3) {
        throw new Error("Invalid channels array passed to performStarAlignment.");
    }

    let meanValues = channels.map(calculateMean);
    let sortedMeans = meanValues.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]);
    let referenceIndex = sortedMeans[1][1];
    let referenceChannel = channels[referenceIndex];
    let targetChannels = channels.filter((_, index) => index !== referenceIndex);

    Console.writeln("Reference channel for Star Alignment: " + referenceChannel);
    Console.writeln("Target channels for Star Alignment: " + targetChannels.join(", "));

    let P = new StarAlignment();
    P.referenceImage = referenceChannel;
    P.referenceIsFile = false;
    P.targets = targetChannels.map((channelId) => [true, false, channelId]);
    P.outputPostfix = "_registered";

    // Execute StarAlignment
    if (!P.executeGlobal()) {
        Console.warningln("Star Alignment failed.");
        return channels; // Return original channels on failure
    }

    // Update mapping for registered images
    return channels.map((channelId, index) => {
        if (index === referenceIndex) {
            return channelId; // Keep reference channel as is
        }
        let registeredId = channelId + "_registered";
        let view = View.viewById(registeredId);
        if (view) {
            generatedViews.push(registeredId);
            return registeredId;
        } else {
            Console.warningln("Registered view not found: " + registeredId);
            return channelId; // Fallback to original ID
        }
    });
}

// Function to apply BlurXTerminator in "Correct Only" mode
function applyBlurXTerminator(viewId) {
    var view = View.viewById(viewId);
    if (view != null) {
        var P = new BlurXTerminator();
        P.ai_file = BLURXTERMINATOR_AI_FILE; // Use platform-specific macro
        P.correct_only = true;             // Enable "Correct Only" mode
        P.correct_first = false;           // Do not correct first
        P.nonstellar_then_stellar = false; // Process all at once
        P.lum_only = false;                // Process all channels
        P.sharpen_stars = 0.50;            // Default sharpening
        P.adjust_halos = 0.00;             // No halo adjustment
        P.nonstellar_psf_diameter = 0.00;  // Auto PSF diameter
        P.auto_nonstellar_psf = true;      // Enable automatic PSF
        P.sharpen_nonstellar = 0.50;       // Default nonstellar sharpening

        if (!P.executeOn(view)) {
            Console.warningln("BlurXTerminator failed on view: " + viewId);
        } else {
            Console.writeln("BlurXTerminator applied to " + viewId + " in 'Correct Only' mode.");
        }
    } else {
        Console.warningln("View not found for BlurXTerminator: " + viewId);
    }
}

// Function to combine channels into an RGB image
function combineChannelsWithLRGB(redChannel, greenChannel, blueChannel, suffix) {
    var P = new ChannelCombination;
    P.colorSpace = ChannelCombination.prototype.RGB;
    P.channels = [
        [true, redChannel], // Red
        [true, greenChannel], // Green
        [true, blueChannel] // Blue
    ];
    P.executeGlobal();

    // Rename the combined image with suffix
    var combinedView = ImageWindow.activeWindow;
    if (combinedView) {
        combinedView.mainView.id = "AstroImagePrimer" + suffix; // Add suffix
        Console.writeln("Combined image renamed to: AstroImagePrimer" + suffix);
    } else {
        Console.warningln("Failed to rename combined image.");
    }
}

function executeWorkflow(dialog) {
    var selectedViewId = dialog.viewList.currentView.id;
    var selectedView = View.viewById(selectedViewId);

    if (!selectedView) {
        Console.warningln("No view selected for processing.");
        return;
    }

    Console.writeln("Workflow starting...");
    var extractedChannels;

    // Determine naming suffix based on reference type
    let suffix = "";
    if (dialog.referenceMeanComboBox.currentItem == 0) {
        suffix = "_Highest";
    } else if (dialog.referenceMeanComboBox.currentItem == 1) {
        suffix = "_Middle";
    } else if (dialog.referenceMeanComboBox.currentItem == 2) {
        suffix = "_Lowest";
    }

    // Extract or select channels
    if (dialog.useIndividualChannelsCheckBox.checked) {
        // Map selected views to channels
        channelMapping = [
            { role: "R", id: dialog.redChannelDropdown.currentView.id },
            { role: "G", id: dialog.greenChannelDropdown.currentView.id },
            { role: "B", id: dialog.blueChannelDropdown.currentView.id }
        ];

        extractedChannels = channelMapping.map((channel) => channel.id);

        if (dialog.starAlignmentCheckBox.checked) {
            extractedChannels = performStarAlignment(dialog, extractedChannels);
            // Update channelMapping after alignment
            channelMapping = channelMapping.map((channel, index) => ({
                role: channel.role,
                id: extractedChannels[index]
            }));
        }
    } else {
        // Handle combined image extraction
        var P = new ChannelExtraction;
        P.colorSpace = ChannelExtraction.prototype.RGB;
        P.channels = [[true, ""], [true, ""], [true, ""]];
        P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
        P.inheritAstrometricSolution = true;
        P.executeOn(selectedView);

        extractedChannels = [
    selectedViewId + "_R",
    selectedViewId + "_G",
    selectedViewId + "_B"
];

// Track the extracted channel views
extractedChannels.forEach(function (channel) {
    let view = View.viewById(channel);
    if (view) {
        generatedViews.push(channel); // Track generated views
        Console.writeln("Tracked view: " + channel);
    } else {
        Console.warningln("Failed to track view: " + channel);
    }
});

if (dialog.starAlignmentCheckBox.checked) {
    extractedChannels = performStarAlignment(dialog, extractedChannels);

    // Ensure generatedViews is an array
if (!Array.isArray(generatedViews)) {
    Console.warningln("Warning: generatedViews was not an array. Resetting to an empty array.");
    generatedViews = []; // Reset to an empty array if necessary
}

// Update generatedViews to track registered images after Star Alignment
generatedViews = extractedChannels.map(channel =>
    channel.endsWith("_registered") ? channel : channel + "_registered"
);

// Debugging output to confirm the registered views are stored
Console.writeln("DEBUG: Updated generatedViews after alignment = " + JSON.stringify(generatedViews));

}

// Map extracted channels to their roles
channelMapping = [
    { role: "R", id: extractedChannels[0] },
    { role: "G", id: extractedChannels[1] },
    { role: "B", id: extractedChannels[2] }
];

    }

    // Calculate mean values
    var meanValues = extractedChannels.map(calculateMean);

    // Determine reference channel
var referenceIndex;
if (dialog.referenceMeanComboBox.currentItem == 0) {
    referenceIndex = meanValues.indexOf(Math.max.apply(null, meanValues)); // Highest mean
} else if (dialog.referenceMeanComboBox.currentItem == 1) {
    var sortedIndices = meanValues
        .map((val, idx) => [val, idx])
        .sort((a, b) => a[0] - b[0]);
    referenceIndex = sortedIndices[1][1]; // Middle mean
} else if (dialog.referenceMeanComboBox.currentItem == 2) {
    referenceIndex = meanValues.indexOf(Math.min.apply(null, meanValues)); // Lowest mean
}

    var referenceChannel = extractedChannels[referenceIndex];
    var targetChannels = extractedChannels.filter((_, index) => index !== referenceIndex);

    Console.writeln("Reference channel for Linear Fit: " + referenceChannel);

    // Update GUI with mean values and reference channel
    var scaledMeans = channelMapping.map((channel) => ({
        role: channel.role,
        mean: Math.round(calculateMean(channel.id) * 65535)
    }));

    dialog.meanValuesLabel.text =
        "Channel Mean Values (16-bit): " +
        scaledMeans
            .map((channel) => {
                // Assign explicit names for each role
                let roleName = {
                    "R": "Red / Ha",
                    "G": "Green / Sii",
                    "B": "Blue / Oiii"
                }[channel.role] || channel.role; // Default to role if not mapped

                return roleName + ": " + channel.mean;
            })
            .join(", ") + // Separate each channel with a comma for inline formatting
        "\nReference Channel: " + referenceChannel;

    // Apply Linear Fit
    targetChannels.forEach(function (targetChannel) {
        applyLinearFit(referenceChannel, targetChannel);
    });

    // Rename or combine channels as per user preference
if (dialog.keepChannelsSeparatedCheckBox.checked) {
    Console.writeln("Keep Channels Separated is checked. Renaming channels...");
    extractedChannels = extractedChannels.map(function (channelId, index) {
        var channelView = View.viewById(channelId);
        if (channelView) {
            // Map roles to more descriptive names
            let roleNames = {
                "R": "R_Ha",
                "G": "G_Sii",
                "B": "B_Oiii"
            };
            var newName = "AstroImagePrimer_" + (roleNames[channelMapping[index].role] || channelMapping[index].role) + suffix; // Add suffix
            channelView.window.mainView.id = newName;
            Console.writeln("Renamed channel: " + channelId + " to " + newName);
            return newName; // Update the extractedChannels array with the new ID
        } else {
            Console.warningln("View not found for renaming: " + channelId);
            return channelId; // Keep the original ID if renaming fails
        }
    });

    if (dialog.starCorrectionCheckBox.checked) {
        Console.writeln("Applying BlurXTerminator to separated channels...");
        extractedChannels.forEach(function (channelId) {
            var channelView = View.viewById(channelId);
            if (channelView) {
                applyBlurXTerminator(channelId);
            } else {
                Console.warningln("View not found for BlurXTerminator: " + channelId);
            }
        });
    }

} else { // This `else` now handles combining the channels.
    combineChannelsWithLRGB(
        extractedChannels[0],
        extractedChannels[1],
        extractedChannels[2],
        suffix // Pass the suffix here
    );

    if (dialog.starCorrectionCheckBox.checked) {
        Console.writeln("Applying BlurXTerminator to combined image...");
        applyBlurXTerminator("AstroImagePrimer" + suffix);
    }
}

// Cleanup logic
if (!dialog.keepChannelsSeparatedCheckBox.checked) {
    Console.writeln("Closing all generated windows...");
    generatedViews.forEach(function (viewId) {
    var win = ImageWindow.windowById(viewId);
    if (win && win.isNull === false) {
        win.forceClose();
        Console.writeln("Closed view: " + viewId);
    } else {
        Console.warningln("Skipping cleanup: View not found or already closed - " + viewId);
    }
});

    generatedViews.length = 0; // Clear the array after cleanup
}

// Auto-clean extracted channels if individual channels were NOT used and separation is NOT enabled
if (!dialog.useIndividualChannelsCheckBox.checked && !dialog.keepChannelsSeparatedCheckBox.checked) {
    let combinedImageName = dialog.viewList.currentView.id;

    if (combinedImageName) {
        let extractedChannels = [
            combinedImageName + "_R",
            combinedImageName + "_G",
            combinedImageName + "_B"
        ];

        Console.writeln("Checking for extracted channel views to close...");

        extractedChannels.forEach(function (channelId) {
            let win = ImageWindow.windowById(channelId);
            if (win && !win.isNull) {
                win.forceClose();
                Console.writeln("Closed extracted channel: " + channelId);

            }
        });
    } else {
        Console.warningln("Combined image selection not found, skipping additional cleanup.");
    }
}

    Console.noteln("Workflow complete.");
}

// Main dialog for the script GUI
function LinearFitDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.sizer = new VerticalSizer;
    this.sizer.margin = 6;
    this.sizer.spacing = 4;
    this.scaledMinWidth = MIN_GUI_WIDTH;
    this.scaledMinHeight = MIN_GUI_HEIGHT;

    this.titleLabel = new Label(this);
    this.titleLabel.text = "Astro Image Primer";
    this.titleLabel.textAlignment = TextAlign_Center;
    this.titleLabel.font = new Font("SansSerif", 20);
    this.sizer.add(this.titleLabel);
    this.sizer.addSpacing(8);

    this.instructionGroupBox = new GroupBox(this);
    this.instructionGroupBox.title = "Instructions";
    this.instructionGroupBox.sizer = new VerticalSizer;
    this.instructionGroupBox.sizer.margin = 6;
    this.instructionGroupBox.sizer.spacing = 4;

    this.instructionLabel = new Label(this.instructionGroupBox);
    this.instructionLabel.text = "This script performs initial correction steps on an image.\n" +
                                 "Choose either a combined image or individual channels by toggling the Use Individual Channels option.\n" +
                                 "Insert your combined image or individual channels.\n" +
                                 "Select the options you want to perform and click execute.\n\n" +
                                 "Options:\n" +
                                 "- Star Correction: Applies BlurXTerminator Correct Only to improve star quality (BlurXterminator Required).\n" +
                                 "- Keep Channels Separated: Keeps extracted channels open after Linear Fit without combining them.\n" +
                                 "- Use Individual Channels: Allows manual selection of color channels.\n" +
                                 "- Star Alignment: Performs the Star Alignment process to properly align your images. (Highly Recommended for Mono Images)\n\n" +
"Click Measure Channel Mean Values to display the mean values of each channel.\n" +
                                 "Click Execute to run the script.\n\n" +
                                 "Written by Tony De Nardo.";
    this.instructionLabel.textAlignment = TextAlign_Center;
    this.instructionLabel.font = new Font("SansSerif", 12);
    this.instructionGroupBox.sizer.add(this.instructionLabel);

    this.sizer.add(this.instructionGroupBox);
    this.sizer.addSpacing(8);

this.viewLabel = new Label(this);
    this.viewLabel.text = "Select Image";
    this.viewLabel.textAlignment = TextAlign_Left;

    this.viewList = new ViewList(this);
    this.viewList.getAll();

    this.viewSectionSizer = new VerticalSizer;
    this.viewSectionSizer.spacing = 2;
    this.viewSectionSizer.add(this.viewLabel);
    this.viewSectionSizer.addSpacing(4);
    this.viewSectionSizer.add(this.viewList);

    this.sizer.add(this.viewSectionSizer);
    this.sizer.addSpacing(8);

    // Select Channels Section
    this.channelsLabel = new Label(this);
    this.channelsLabel.text = "Select Channels";
    this.channelsLabel.textAlignment = TextAlign_Left;

    // Red Channel Label and Dropdown
    this.redChannelLabel = new Label(this);
    this.redChannelLabel.text = "Red / Ha";
    this.redChannelLabel.textAlignment = TextAlign_Left;

    this.redChannelDropdown = new ViewList(this);
    this.redChannelDropdown.getAll();
    this.redChannelDropdown.enabled = false;

    // Green Channel Label and Dropdown
    this.greenChannelLabel = new Label(this);
    this.greenChannelLabel.text = "Green / Sii";
    this.greenChannelLabel.textAlignment = TextAlign_Left;

    this.greenChannelDropdown = new ViewList(this);
    this.greenChannelDropdown.getAll();
    this.greenChannelDropdown.enabled = false;

    // Blue Channel Label and Dropdown
    this.blueChannelLabel = new Label(this);
    this.blueChannelLabel.text = "Blue / Oiii";
    this.blueChannelLabel.textAlignment = TextAlign_Left;

    this.blueChannelDropdown = new ViewList(this);
    this.blueChannelDropdown.getAll();
    this.blueChannelDropdown.enabled = false;

    // Layout for Channels Section
    this.channelsSectionSizer = new VerticalSizer;
    this.channelsSectionSizer.spacing = 4;
    this.channelsSectionSizer.add(this.channelsLabel);
    this.channelsSectionSizer.addSpacing(6);
    this.channelsSectionSizer.add(this.redChannelLabel);
    this.channelsSectionSizer.add(this.redChannelDropdown);
    this.channelsSectionSizer.addSpacing(4);
    this.channelsSectionSizer.add(this.greenChannelLabel);
    this.channelsSectionSizer.add(this.greenChannelDropdown);
    this.channelsSectionSizer.addSpacing(4);
    this.channelsSectionSizer.add(this.blueChannelLabel);
    this.channelsSectionSizer.add(this.blueChannelDropdown);

    this.sizer.add(this.channelsSectionSizer);
    this.sizer.addSpacing(8);

    this.optionsGroupBox = new GroupBox(this);
    this.optionsGroupBox.title = "Options";
    this.optionsGroupBox.sizer = new VerticalSizer;
    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 4;

    this.useIndividualChannelsCheckBox = new CheckBox(this.optionsGroupBox);
    this.useIndividualChannelsCheckBox.text = "Use Individual Channels";
    this.optionsGroupBox.sizer.add(this.useIndividualChannelsCheckBox);

    this.starCorrectionCheckBox = new CheckBox(this.optionsGroupBox);
    this.starCorrectionCheckBox.text = "Star Correction (BlurXterminator Required)";
    this.optionsGroupBox.sizer.add(this.starCorrectionCheckBox);

    this.keepChannelsSeparatedCheckBox = new CheckBox(this.optionsGroupBox);
    this.keepChannelsSeparatedCheckBox.text = "Keep Channels Separated (Recommended for Mono Images)";
    this.optionsGroupBox.sizer.add(this.keepChannelsSeparatedCheckBox);

    this.starAlignmentCheckBox = new CheckBox(this.optionsGroupBox);
    this.starAlignmentCheckBox.text = "Star Alignment (Recommended for Mono Images)";
    this.optionsGroupBox.sizer.add(this.starAlignmentCheckBox);

    this.sizer.add(this.optionsGroupBox);
    this.sizer.addSpacing(8);

    this.referenceLabel = new Label(this);
this.referenceLabel.text = "Select Reference Type:\nClick 'Measure Channel Mean Values' above to get channel values";
this.referenceLabel.textAlignment = TextAlign_Left;


    this.referenceMeanComboBox = new ComboBox(this);
    this.referenceMeanComboBox.addItem("Highest Mean");
    this.referenceMeanComboBox.addItem("Middle Mean");
    this.referenceMeanComboBox.addItem("Lowest Mean");

    this.referenceSectionSizer = new VerticalSizer;
    this.referenceSectionSizer.spacing = 2;
    this.referenceSectionSizer.add(this.referenceLabel);
    this.referenceSectionSizer.addSpacing(4);
    this.referenceSectionSizer.add(this.referenceMeanComboBox);
    this.referenceSectionSizer.addStretch();

// Create "Measure Channel Means" Button
    this.measureMeansButton = new PushButton(this);
    this.measureMeansButton.text = "Measure Channel Mean Values";  // Set button text
    this.measureMeansButton.onClick = function () {

if (this.starCorrectionCheckBox.checked ||
        this.keepChannelsSeparatedCheckBox.checked ||
        this.starAlignmentCheckBox.checked) {

        Console.warningln("Channel Measurement Selected. Script Options Detected. Click Execute to Perform Full Script");
    }

let selectedViewId = this.viewList.currentView.id;
    let selectedView = View.viewById(selectedViewId);

    if (!selectedView) {
        Console.warningln("No view selected for processing.");
        return;
    }

    Console.writeln("Workflow starting...");
    var extractedChannels;

    // Determine naming suffix based on reference type
    let suffix = "";
    if (this.referenceMeanComboBox.currentItem == 0) {
        suffix = "_Highest";
    } else if (this.referenceMeanComboBox.currentItem == 1) {
        suffix = "_Middle";
    } else if (this.referenceMeanComboBox.currentItem == 2) {
        suffix = "_Lowest";
    }

    // Extract or select channels
    if (this.useIndividualChannelsCheckBox.checked) {
    // Map selected views to channels
    channelMapping = [
        { role: "R", id: this.redChannelDropdown.currentView.id },
        { role: "G", id: this.greenChannelDropdown.currentView.id },
        { role: "B", id: this.blueChannelDropdown.currentView.id }
    ];

    extractedChannels = channelMapping.map((channel) => channel.id);

    // ✅ Only measure means—DO NOT modify channels
    if (this.starAlignmentCheckBox.checked) {
        Console.writeln("Skipping Star Alignment during measurement.");
    }
    } else {
        // Handle combined image extraction
        var P = new ChannelExtraction;
        P.colorSpace = ChannelExtraction.prototype.RGB;
        P.channels = [[true, ""], [true, ""], [true, ""]];
        P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
        P.inheritAstrometricSolution = true;
        P.executeOn(selectedView);

        extractedChannels = [
            selectedViewId + "_R",
            selectedViewId + "_G",
            selectedViewId + "_B"
        ];
    }

    // Verify extracted channels
    extractedChannels = extractedChannels.filter(channelId => {
        let exists = View.viewById(channelId) !== null;
        Console.writeln("Checking extracted channel: " + channelId + " -> " + (exists ? "Exists" : "NOT FOUND"));
        return exists;
    });

    if (extractedChannels.length !== 3) {
        Console.warningln("Not all three channels were found. Measurement aborted.");
        return;
    }

    // Compute mean values
    let meanValues = extractedChannels.map(calculateMean);

    // Determine reference channel using the working method
    let referenceIndex;
    if (this.referenceMeanComboBox.currentItem == 0) {
        referenceIndex = meanValues.indexOf(Math.max.apply(null, meanValues)); // Highest mean
    } else if (this.referenceMeanComboBox.currentItem == 1) {
        let sortedIndices = meanValues.map((val, idx) => [val, idx]).sort((a, b) => a[0] - b[0]);
        referenceIndex = sortedIndices[1][1]; // Middle mean
    } else if (this.referenceMeanComboBox.currentItem == 2) {
        referenceIndex = meanValues.indexOf(Math.min.apply(null, meanValues)); // Lowest mean
    }

    let referenceChannel = extractedChannels[referenceIndex];

    // Scale mean values to 16-bit and assign labels using the **same method** as the primary function
    let scaledMeans = extractedChannels.map(function (channelId, index) {
        return {
            role: ["Red / Ha", "Green / Sii", "Blue / Oiii"][index],
            mean: Math.round(meanValues[index] * 65535)
        };
    });

    // Update GUI label
    this.meanValuesLabel.text =
        "Channel Mean Values (16-bit): " +
        scaledMeans.map(function (channel) {
            return channel.role + ": " + channel.mean;
        }).join(", ") +
        "\nReference Channel: " + referenceChannel;

    // Print measured values to the console
    Console.writeln("Measured Channel Means: " +
        scaledMeans.map(function (channel) {
            return channel.role + ": " + channel.mean;
        }).join(", "));

// ✅ **Cleanup: Close the extracted channel views, but only if they were extracted**
if (!this.useIndividualChannelsCheckBox.checked) {
    Console.writeln("Closing temporary measurement windows...");
    extractedChannels.forEach(function (channelId) {
        let win = ImageWindow.windowById(channelId);
        if (win) {
            win.forceClose();
            Console.writeln("Closed view: " + channelId);
        } else {
            Console.warningln("View not found for cleanup: " + channelId);
        }
    });
} else {
    Console.writeln("Individual channels selected. Keeping image windows open.");
}

}.bind(this);

    // Add the new button to the GUI layout
    this.sizer.add(this.measureMeansButton);

    this.sizer.add(this.referenceSectionSizer);
    this.sizer.addSpacing(8);

    this.meanValuesContainer = new Control(this);
    this.meanValuesContainer.setScaledMinSize(200, 100);
    this.meanValuesContainer.styleSheet = "background-color: white; border: 1px solid gray; padding: 6px;";

    this.meanValuesLabel = new Label(this.meanValuesContainer);
    this.meanValuesLabel.text = "Channel Mean Values: R: -, G: -, B: -\nSelected Reference: None";
    this.meanValuesLabel.textAlignment = TextAlign_Left;

    // Adjust font size for better readability
    this.meanValuesLabel.font = new Font("SansSerif", 12);

    this.meanValuesContainer.sizer = new VerticalSizer;
    this.meanValuesContainer.sizer.margin = 6;
    this.meanValuesContainer.sizer.add(this.meanValuesLabel);

    this.sizer.add(this.meanValuesContainer);
    this.sizer.addSpacing(8);

    this.useIndividualChannelsCheckBox.onCheck = function (checked) {
        this.viewList.enabled = !checked;
        this.redChannelDropdown.enabled = checked;
        this.greenChannelDropdown.enabled = checked;
        this.blueChannelDropdown.enabled = checked;
    }.bind(this);

    this.execButton = new PushButton(this);
    this.execButton.text = "Execute";
    this.execButton.onClick = function () {
        executeWorkflow(this);
        Console.hide();
    }.bind(this);

    this.sizer.add(this.execButton);

    this.windowTitle = "Astro Image Primer";
}
LinearFitDialog.prototype = new Dialog;

// Main function
function main() {
    var dialog = new LinearFitDialog();
    dialog.execute();
}

main();
