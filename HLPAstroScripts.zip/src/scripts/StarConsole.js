#feature-id   StarConsole : HLP > Star Console
#feature-info This script measures FWHM and performs BlurXterminator and StarXterminator

#include <pjsr/StdIcon.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/NumericControl.jsh>


#ifeq __PI_PLATFORM__ MACOSX
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.mlpackage"
#define STARXTERMINATOR_AI_FILE "StarXTerminator.lite.nonoise.11.mlpackage"
#endif
#ifeq __PI_PLATFORM__ MSWINDOWS
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.pb"
#define STARXTERMINATOR_AI_FILE "StarXTerminator.lite.nonoise.11.pb"
#endif
#ifeq __PI_PLATFORM__ LINUX
#define BLURXTERMINATOR_AI_FILE "BlurXTerminator.4.pb"
#define STARXTERMINATOR_AI_FILE "StarXTerminator.lite.nonoise.11.pb"
#endif

function executeBlurXTerminator(view, fwhm, sharpenStellar, sharpenNonStellar) {
    Console.writeln("Executing BlurXTerminator on view: " + view.fullId);

    let P = new BlurXTerminator();
    P.ai_file = BLURXTERMINATOR_AI_FILE; // Use platform-specific macro
    P.correct_only = false;
    P.correct_first = false;
    P.nonstellar_then_stellar = false;
    P.lum_only = false;
    P.sharpen_stars = sharpenStellar; // Proper numeric value
    P.adjust_halos = 0.00;
    P.sharpen_nonstellar = sharpenNonStellar; // Proper numeric value

    // Check if FWHM exceeds 8
    if (fwhm > 8) {
        Console.noteln("FWHM exceeds 8. Using BlurXTerminator in auto mode.");
        P.auto_nonstellar_psf = true; // Enable auto mode
        P.nonstellar_psf_diameter = 0.00; // Ensure this is set to 0 for auto mode
    } else {
        P.auto_nonstellar_psf = false; // Disable auto mode
        P.nonstellar_psf_diameter = Math.round(fwhm * 100) / 100; // Round to nearest hundredth
        Console.noteln("BlurXTerminator PSF Diameter set to: " + P.nonstellar_psf_diameter);
    }

    try {
        if (!P.executeOn(view)) {
            throw new Error("BlurXTerminator execution failed.");
        }

        // Rename the image to include "_StarConsole"
        let newName = view.id + "_StarConsole";
        view.window.mainView.id = newName;
        Console.writeln("Image renamed to: " + newName);

        // Display the PSF diameter used in the console
        if (P.auto_nonstellar_psf) {
            Console.noteln("BlurXTerminator used Auto PSF mode.");
        } else {
            Console.noteln("BlurXTerminator PSF Diameter used: " + P.nonstellar_psf_diameter.toFixed(2));
        }
    } catch (error) {
        Console.warningln("Error executing BlurXTerminator: " + error.message);
        new MessageBox("BlurXTerminator failed to execute.", "Error", StdIcon_Error, StdButton_Ok).execute();
    }
}

function executeStarXTerminator(view, unscreen, useLargeOverlap) {
    Console.writeln("Executing StarXTerminator on view: " + view.fullId);

    let P = new StarXTerminator();
    P.ai_file = STARXTERMINATOR_AI_FILE; // Use platform-specific macro
    P.stars = true; // Extract stars
    P.unscreen = unscreen; // Use the passed unscreen mode
    P.overlap = useLargeOverlap ? 0.50 : 0.20; // Use 0.50 if checkbox is enabled, otherwise default 0.20

    Console.writeln("StarXTerminator Overlap set to: " + P.overlap);

    try {
        if (!P.executeOn(view)) {
            throw new Error("StarXTerminator execution failed.");
        }
        Console.writeln("StarXTerminator executed successfully.");
    } catch (error) {
        Console.warningln("Error executing StarXTerminator: " + error.message);
        new MessageBox("StarXTerminator failed to execute.", "Error", StdIcon_Error, StdButton_Ok).execute();
    }
}

function executeStarNet(view, useLinear) {
    Console.writeln("Executing StarNet++ on view: " + view.fullId);

    let P = new StarNet2();
    P.stride = StarNet2.prototype.defStride;
    P.mask = true;
    P.linear = useLinear; // Use the passed mode
    P.upsample = false;
    P.shadows_clipping = -2.80;
    P.target_background = 0.25;

    try {
        if (!P.executeOn(view)) {
            throw new Error("StarNet++ execution failed.");
        }
    } catch (error) {
        Console.warningln("Error executing StarNet++: " + error.message);
        new MessageBox("StarNet++ failed to execute.", "Error", StdIcon_Error, StdButton_Ok).execute();
    }
}

function extractLuminance(view) {
    let P = new ChannelExtraction();
    P.colorSpace = ChannelExtraction.prototype.CIELch;
    P.channels = [[true, ""], [false, ""], [false, ""]];
    P.executeOn(view);

    let activeWindow = ImageWindow.activeWindow;
    if (!activeWindow.isNull) {
        return { view: activeWindow.mainView, window: activeWindow };
    } else {
        throw new Error("Luminance extraction failed.");
    }
}

function saveViewAsTemporaryFile(view) {
    let tempFilePath = File.systemTempDirectory + "/tempImage.xisf";
    try {
        if (!view.window.saveAs(tempFilePath, false, false)) {
            throw new Error("Failed to save the view as a file.");
        }
        return tempFilePath;
    } catch (error) {
        Console.warningln("Error saving temporary file: " + error.message);
        return null;
    }
}

function measureFWHM(filePath, originalView) {
    Console.writeln("Processing file: " + filePath);

    let P = new SubframeSelector();
    P.routine = SubframeSelector.prototype.MeasureSubframes;
    P.nonInteractive = true;
    P.subframes = [[true, filePath, "", ""]];
    P.fileCache = true;
    P.structureLayers = 5;
    P.sensitivity = 0.4;
    P.psfFit = SubframeSelector.prototype.Moffat4;
    P.maxPSFFits = 8000;

    if (!P.executeGlobal()) {
        throw new Error("SubframeSelector execution failed for: " + filePath);
    }

    Console.writeln("SubframeSelector executed successfully.");

    if (P.measurements.length > 0) {
        let measurement = P.measurements[0];
        Console.writeln(
            "FWHM: " + measurement[5] +
            ", Eccentricity: " + measurement[6] +
            ", Stars Detected: " + measurement[14]
        );
        return {
            FWHM: measurement[5],
            Eccentricity: measurement[6],
            StarsDetected: measurement[14],
            ImageName: originalView.fullId,
        };
    } else {
        throw new Error("No valid measurements found in: " + filePath);
    }
}

function processImage(view, fullStarCorrection, starRemoval, stellarSharpeningValue, nonStellarSharpeningValue, starRemovalMethod, useLargeOverlap) {

    let tempFilePath;
    let luminanceWindow = null;
    let originalView = view; // Keep a reference to the original image view

    try {
        if (view.image.isColor) {
            Console.writeln("Detected color image. Extracting luminance...");
            let luminanceResult = extractLuminance(view);
            view = luminanceResult.view;
            luminanceWindow = luminanceResult.window;
        }

        tempFilePath = saveViewAsTemporaryFile(view);
        if (!tempFilePath) {
            throw new Error("Failed to save the temporary file for processing.");
        }

        let result = measureFWHM(tempFilePath, view);
        if (result) {
            if (fullStarCorrection) {
                executeBlurXTerminator(
                    originalView,
                    result.FWHM,
                    stellarSharpeningValue, // Use passed stellar sharpening value
                    nonStellarSharpeningValue // Use passed non-stellar sharpening value
                );
            }

            // Star removal process
            if (starRemoval) {
    Console.writeln("Star removal is enabled.");
    Console.writeln("Selected Star Removal Method: " + starRemovalMethod);

    if (starRemovalMethod === "StarXTerminator") {
        executeStarXTerminator(originalView, true, useLargeOverlap); // ✅ Uses correct parameter
    } else if (starRemovalMethod === "StarXStarsOnly") {
        executeStarXTerminator(originalView, false, useLargeOverlap); // ✅ Uses correct parameter
    } else if (starRemovalMethod === "StarNetLinear") {
        executeStarNet(originalView, true);
    } else if (starRemovalMethod === "StarNetNonLinear") {
        executeStarNet(originalView, false);
    } else {
        Console.warningln("Unknown Star Removal Method: " + starRemovalMethod);
    }
}

            // Return the measurements
            return {
                FWHM: result.FWHM,
                Eccentricity: result.Eccentricity,
                StarsDetected: result.StarsDetected,
                ImageName: originalView.fullId, // Optional for display in TreeBox
            };
        }
    } catch (error) {
        Console.warningln("An error occurred during image processing: " + error.message);
        return { error: error.message }; // Return an error object
    } finally {
        if (tempFilePath) {
            try {
                File.remove(tempFilePath);
                Console.writeln("Deleted temporary file: " + tempFilePath);
            } catch (fileError) {
                Console.warningln("Failed to delete temporary file: " + fileError.message);
            }
        }

        if (luminanceWindow) {
            Console.writeln("Closing extracted luminance window...");
            luminanceWindow.forceClose();
        }

Console.noteln("Star Console Completed");
        Console.hide();

}

    // Default return in case no result is generated
    return null;
}

function StarConsoleDialog() {
    this.__base__ = Dialog;
    this.__base__();

this.updateSubFrameStarCheckBoxState = function () {
    // Enable SubFrame Star Check only if neither Full Star Correction nor Star Removal are checked
    this.subFrameStarCheckBox.enabled =
        !this.fullStarCorrectionCheckBox.checked &&
        !this.starRemovalCheckBox.checked;
}.bind(this);

this.saveParameters = function () {
    Parameters.clear();
    Parameters.set("fullStarCorrection", this.fullStarCorrectionCheckBox.checked);
    Parameters.set("starRemoval", this.starRemovalCheckBox.checked);
    Parameters.set("stellarSharpening", this.stellarSharpeningSlider.value);
    Parameters.set("nonStellarSharpening", this.nonStellarSharpeningSlider.value);
    Parameters.set("enableStarXLargeOverlap", this.starXLargeOverlapCheckBox.checked); // Save Large Overlap checkbox state

    // Save the star removal method
    if (this.starXterminatorRadio.checked) {
        Parameters.set("starRemovalMethod", "StarXTerminator");
    } else if (this.starXStarsOnlyRadio.checked) {
        Parameters.set("starRemovalMethod", "StarXStarsOnly");
    } else if (this.starNetLinearRadio.checked) {
        Parameters.set("starRemovalMethod", "StarNetLinear");
    } else if (this.starNetNonLinearRadio.checked) {
        Parameters.set("starRemovalMethod", "StarNetNonLinear");
    } else {
        Parameters.set("starRemovalMethod", "None");
    }
};

this.loadParameters = function () {
    if (Parameters.has("fullStarCorrection")) {
        this.fullStarCorrectionCheckBox.checked = Parameters.getBoolean("fullStarCorrection");
    }
    if (Parameters.has("starRemoval")) {
        this.starRemovalCheckBox.checked = Parameters.getBoolean("starRemoval");
    }
    if (Parameters.has("stellarSharpening")) {
        this.stellarSharpeningSlider.setValue(Parameters.getReal("stellarSharpening"));
    }
    if (Parameters.has("nonStellarSharpening")) {
        this.nonStellarSharpeningSlider.setValue(Parameters.getReal("nonStellarSharpening"));
    }
    if (Parameters.has("enableStarXLargeOverlap")) {
        this.starXLargeOverlapCheckBox.checked = Parameters.getBoolean("enableStarXLargeOverlap"); // Load Large Overlap state
    }

    // Load the selected star removal method
    if (Parameters.has("starRemovalMethod")) {
        const method = Parameters.getString("starRemovalMethod");
        this.starXterminatorRadio.checked = (method === "StarXTerminator");
        this.starXStarsOnlyRadio.checked = (method === "StarXStarsOnly");
        this.starNetLinearRadio.checked = (method === "StarNetLinear");
        this.starNetNonLinearRadio.checked = (method === "StarNetNonLinear");

        Console.writeln("Loaded Star Removal Method: " + method);
    } else {
        Console.writeln("No Star Removal Method loaded; defaulting to None.");
    }
};

    this.originalFileOrder = []; // To track original order for sorting

    // --- Subframe Star Check ---
this.subFrameStarCheckBox = new CheckBox(this);
this.subFrameStarCheckBox.text = "SubFrame Star Check";
this.subFrameStarCheckBox.toolTip = "Check subframes for star properties.";
this.subFrameStarCheckBox.onCheck = function (checked) {
    this.viewList.enabled = !checked; // Disable dropdown if checked
    this.addFilesButton.enabled = checked; // Enable Add Files button if checked

    if (checked) {
        this.fullStarCorrectionCheckBox.checked = false;
        this.starRemovalCheckBox.checked = false;
    }

    this.updateSubFrameStarCheckBoxState();
}.bind(this);

// --- Full Star Correction ---
this.fullStarCorrectionCheckBox = new CheckBox(this);
this.fullStarCorrectionCheckBox.text = "Full Star Correction (BlurXTerminator Required)";
this.fullStarCorrectionCheckBox.toolTip = "Apply BlurXTerminator correction with measured FWHM.";
this.fullStarCorrectionCheckBox.onCheck = function (checked) {
    if (checked) {
        this.subFrameStarCheckBox.checked = false; // Uncheck SubFrame Star Check
        this.addFilesButton.enabled = false; // Disable Add Files button
        this.viewList.enabled = true; // Re-enable dropdown
    }
    this.updateSubFrameStarCheckBoxState();
}.bind(this);

// --- Stellar Sharpening Slider ---
this.stellarSharpeningSlider = new NumericControl(this);
this.stellarSharpeningSlider.label.text = "Stellar Sharpening:";
this.stellarSharpeningSlider.label.width = 120; // Ensure label width matches style
this.stellarSharpeningSlider.setRange(0, 0.70); // Actual range for values
this.stellarSharpeningSlider.setPrecision(2); // Display values with 2 decimal places
this.stellarSharpeningSlider.slider.setRange(0, 100); // Scale slider range to 0-100 for finer steps
this.stellarSharpeningSlider.setValue(0.50); // Default to 0.50
this.stellarSharpeningSlider.toolTip = "Adjust the level of stellar sharpening (0 to 0.70). Default is 0.50.";
this.stellarSharpeningSlider.onValueUpdated = function (value) {
    let scaledValue = Math.round(value * 100) / 100; // Ensure proper scaling
    this.stellarSharpeningSlider.setValue(scaledValue); // Update slider display value
}.bind(this);

// --- Non-Stellar Sharpening Slider ---
this.nonStellarSharpeningSlider = new NumericControl(this);
this.nonStellarSharpeningSlider.label.text = "Non-Stellar Sharpening:";
this.nonStellarSharpeningSlider.label.width = 120; // Ensure label width matches style
this.nonStellarSharpeningSlider.setRange(0, 1.0); // Actual range for values
this.nonStellarSharpeningSlider.setPrecision(2); // Display values with 2 decimal places
this.nonStellarSharpeningSlider.slider.setRange(0, 100); // Scale slider range to 0-100 for finer steps
this.nonStellarSharpeningSlider.setValue(0.50); // Default to 0.50
this.nonStellarSharpeningSlider.toolTip = "Adjust the level of non-stellar sharpening (0 to 1.0). Default is 0.50.";
this.nonStellarSharpeningSlider.onValueUpdated = function (value) {
    let scaledValue = Math.round(value * 100) / 100; // Ensure proper scaling
    this.nonStellarSharpeningSlider.setValue(scaledValue); // Update slider display value
}.bind(this);

    // --- Star Removal ---
    this.starRemovalCheckBox = new CheckBox(this);
this.starRemovalCheckBox.text = "Star Removal";
this.starRemovalCheckBox.toolTip = "Remove stars using the selected method.";
this.starRemovalCheckBox.onCheck = function (checked) {
    if (checked) {
        this.subFrameStarCheckBox.checked = false; // Uncheck SubFrame Star Check
        this.addFilesButton.enabled = false; // Disable Add Files button
        this.viewList.enabled = true; // Re-enable dropdown
    }
    this.updateSubFrameStarCheckBoxState();
}.bind(this);

// --- Star Removal Method Radio Buttons ---
// Ensure radio button changes do not affect the checkbox logic
// --- Star Removal Method Radio Buttons ---
this.starRemovalMethodGroup = new Control(this);
this.starRemovalMethodGroup.visible = true;

let methodSizer = new VerticalSizer(this.starRemovalMethodGroup);
methodSizer.margin = 4;
methodSizer.spacing = 4;

// Radio Button: StarXTerminator Unscreen Stars
this.starXterminatorRadio = new RadioButton(this.starRemovalMethodGroup);
this.starXterminatorRadio.text = "StarXTerminator (Unscreen Stars)";
this.starXterminatorRadio.checked = true; // Default selection
this.starXterminatorRadio.onCheck = function (checked) {
    if (checked) {
        Console.writeln("StarXTerminator (Unscreen Stars) selected.");
    }
}.bind(this);

// Radio Button: StarXTerminator Stars Only Image
this.starXStarsOnlyRadio = new RadioButton(this.starRemovalMethodGroup); // Ensure correct property name
this.starXStarsOnlyRadio.text = "StarXTerminator (Stars Only Image)";
this.starXStarsOnlyRadio.onCheck = function (checked) {
    if (checked) {
        Console.writeln("StarXTerminator Stars Only Image selected.");
    }
}.bind(this);

// Checkbox: Enable StarXterminator Large Overlap
this.starXLargeOverlapCheckBox = new CheckBox(this);
this.starXLargeOverlapCheckBox.text = "Enable StarXterminator Large Overlap";
this.starXLargeOverlapCheckBox.toolTip = "If enabled, StarXterminator will use an overlap of 0.50 instead of the default 0.20.";

// Radio Button: StarNet++ Linear
this.starNetLinearRadio = new RadioButton(this.starRemovalMethodGroup);
this.starNetLinearRadio.text = "StarNet++ Linear";
this.starNetLinearRadio.onCheck = function (checked) {
    if (checked) {
        Console.writeln("StarNet++ Linear selected.");
    }
}.bind(this);

// Radio Button: StarNet++ Non-Linear
this.starNetNonLinearRadio = new RadioButton(this.starRemovalMethodGroup);
this.starNetNonLinearRadio.text = "StarNet++ Non-Linear";
this.starNetNonLinearRadio.onCheck = function (checked) {
    if (checked) {
        Console.writeln("StarNet++ Non-Linear selected.");
    }
}.bind(this);

// Add the radio buttons to the sizer
methodSizer.add(this.starXterminatorRadio);
methodSizer.add(this.starXStarsOnlyRadio);
methodSizer.add(this.starXLargeOverlapCheckBox);
methodSizer.add(this.starNetLinearRadio);
methodSizer.add(this.starNetNonLinearRadio);

this.starRemovalMethodGroup.sizer = methodSizer;

// --- Instruction Label ---
this.instructionLabel = new Label(this);
this.instructionLabel.text = "Select an image to analyze its FWHM.\n\n" +
"Choose Full Star Correction to additionally perform the full BlurXterminator.\n" +
"Adjust Stellar and Non-Stellar sharpening sliders to desired level.\n" +
"Note the default Stellar and Non-Stellar sliders reflect BlurXterminator default settings.\n" +
"Choose Star Removal and method of removal to also remove the stars from your image. \n\n" +
"Select Subframe Star Check and select light frames to get FWHM for each frame.\n" +
"Use the list to select frames to remove from the list, save the selected frames or save remaining frames.\n\n" +
"Written by Tony De Nardo";
this.instructionLabel.textAlignment = TextAlign_Center;
this.instructionLabel.font = new Font("SansSerif", 14); // Change font size to 14

    // --- View List ---
    this.viewList = new ViewList(this);
    this.viewList.getAll();

    // --- Add Light Frame Files Button ---
    this.addFilesButton = new PushButton(this);
    this.addFilesButton.text = "Add Light Subframe Files";
    this.addFilesButton.enabled = false;
    this.addFilesButton.toolTip = "Add light subframe files for batch processing.";
    this.addFilesButton.onClick = function () {
    let fileDialog = new OpenFileDialog();
    fileDialog.multipleSelections = true;
    fileDialog.caption = "Select Light Subframe Files";
    fileDialog.filters = [
        ["All Supported Images", "*.xisf;*.fits;*.fit;*.tif;*.tiff"],
        ["PixInsight Images", "*.xisf"],
        ["FITS Images", "*.fits;*.fit"],
        ["TIFF Images", "*.tif;*.tiff"],
        ["All Files", "*"]
    ];

    if (fileDialog.execute()) {
        let selectedFiles = fileDialog.fileNames;
        this.treeBox.clear(); // Clear the TreeBox for new entries
        this.originalFileOrder = []; // Reset original order
        for (let filePath of selectedFiles) {
            try {
                let result = measureFWHM(filePath, { fullId: File.extractName(filePath) });
                if (result) {
                    let node = new TreeBoxNode(this.treeBox);
                    node.setText(0, File.extractName(filePath)); // Display file name
                    node.setText(1, result.FWHM.toFixed(4)); // FWHM result
                    node.setText(2, result.Eccentricity.toFixed(4)); // Eccentricity result
                    node.setText(3, result.StarsDetected.toString()); // Stars Detected
                    node.filePath = filePath; // Store full file path
                    node.setAlignment(0, TextAlign_Right); // Align text in the "Image Name" column to the right
                }
            } catch (error) {
                Console.warningln("Error processing file: " + filePath + " - " + error.message);
            }
        }
    } else {
        Console.writeln("No files were selected.");
    }
}.bind(this);

    // --- TreeBox ---
this.treeBox = new TreeBox(this);
this.treeBox.alternateRowColor = true;
this.treeBox.numberOfColumns = 4; // Updated to 4 columns
this.treeBox.headerVisible = true;
this.treeBox.setHeaderText(0, "Image Name");
this.treeBox.setHeaderText(1, "FWHM");
this.treeBox.setHeaderText(2, "Eccentricity"); // New column for Eccentricity
this.treeBox.setHeaderText(3, "Stars Detected"); // New column for Stars Detected
this.treeBox.multipleSelection = true;
this.treeBox.setMinHeight(120);
this.treeBox.horizontalScrollBarVisible = true; // Enable horizontal scrolling
this.treeBox.adjustColumnWidthToContents(0); // Dynamically adjust column width to fit content
this.treeBox.setColumnWidth(0, 300); // Example width

    // --- Result TextBox ---
    this.resultTextBox = new TextBox(this);
    this.resultTextBox.readOnly = true;
    this.resultTextBox.styleSheet = "font-family: monospace; font-size: 12pt; padding: 4px;";
    this.resultTextBox.text = "Star Information:\nFWHM\nEccentricity\nStars Detected\nBlurX PSF Diameter Used: None";
    this.resultTextBox.setScaledMinHeight(80);

// --- New Instance Button ---
this.newInstanceButton = new ToolButton(this);
this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
this.newInstanceButton.setScaledFixedSize(24, 24);
this.newInstanceButton.toolTip = "Drag to create a new instance with current settings";

this.newInstanceButton.onMousePress = function () {
    this.saveParameters(); // Save parameters before exporting
    this.newInstance();    // Create a new instance
    Console.writeln("New instance created.");
}.bind(this);

// --- Measure FWHM Button ---
this.measureFWHMButton = new PushButton(this);
this.measureFWHMButton.text = "Measure FWHM";
this.measureFWHMButton.toolTip = "Measure FWHM of the selected image.";
this.measureFWHMButton.setMinWidth(100); // Adjust width as needed

// Button click behavior
this.measureFWHMButton.onClick = function () {
    let selectedView = this.viewList.currentView;

    if (!selectedView) {
        new MessageBox("Please select an image view.", "Error", StdIcon_Error, StdButton_Ok).execute();
        return;
    }

    try {
        // Determine which star removal method is selected
        let starRemovalMethod = "None";
if (this.starXterminatorRadio.checked) {
    starRemovalMethod = "StarXTerminator";
} else if (this.starXStarsOnlyRadio.checked) {
    starRemovalMethod = "StarXStarsOnly";
} else if (this.starNetLinearRadio.checked) {
    starRemovalMethod = "StarNetLinear";
} else if (this.starNetNonLinearRadio.checked) {
    starRemovalMethod = "StarNetNonLinear";
}

        let result = processImage(
    selectedView,
    this.fullStarCorrectionCheckBox.checked,
    this.starRemovalCheckBox.checked,
    this.stellarSharpeningSlider.value,
    this.nonStellarSharpeningSlider.value,
    starRemovalMethod,
    this.starXLargeOverlapCheckBox.checked // ✅ Pass the checkbox value
);

        if (result) {
            let resultText =
                "Star Information:\n" +
                "FWHM: " + result.FWHM.toFixed(4) + "\n" +
                "Eccentricity: " + result.Eccentricity.toFixed(4) + "\n" +
                "Stars Detected: " + result.StarsDetected;

            if (this.fullStarCorrectionCheckBox.checked) {
                let roundedFWHM = Math.round(result.FWHM * 100) / 100;
                resultText += "\nBlurX PSF Diameter Used: " + roundedFWHM;
            } else {
                resultText += "\nBlurX PSF Diameter Used: None";
            }

            this.resultTextBox.text = resultText;

            // Clear the TreeBox and update it with new data
            this.treeBox.clear();
            let node = new TreeBoxNode(this.treeBox);
            node.setText(0, result.ImageName);
            node.setText(1, result.FWHM.toFixed(4));
            node.setText(2, result.Eccentricity.toFixed(4));
            node.setText(3, result.StarsDetected.toString());
        }
    } catch (error) {
        Console.warningln("Error: " + error.message);
        this.resultTextBox.text = "Star Information:\nError: " + error.message + "\nBlurX PSF Diameter Used: None";
        this.treeBox.clear();
    }
}.bind(this);

    // --- Action Buttons ---
    this.deleteButton = new PushButton(this);
    this.deleteButton.text = "Delete Selected";
    this.deleteButton.onClick = function () {
        let selectedNodes = this.treeBox.selectedNodes;
        if (selectedNodes.length === 0) {
            (new MessageBox("No items selected for deletion.", "Error", StdIcon_Error, StdButton_Ok)).execute();
            return;
        }
        selectedNodes.forEach(node => this.treeBox.remove(this.treeBox.childIndex(node)));
    }.bind(this);

    // --- Save Selected Button ---
this.saveSelectedButton = new PushButton(this);
this.saveSelectedButton.text = "Save Selected";
this.saveSelectedButton.toolTip = "Save selected images to a folder of your choice.";
this.saveSelectedButton.onClick = function () {
    let selectedNodes = this.treeBox.selectedNodes;
    if (selectedNodes.length === 0) {
        (new MessageBox("No items selected for saving.", "Error", StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let folderDialog = new GetDirectoryDialog();
    folderDialog.caption = "Select Save Location";
    if (folderDialog.execute()) {
        let savePath = folderDialog.directory;
        for (let node of selectedNodes) {
            if (!node.filePath || !File.exists(node.filePath)) {
                Console.warningln("File not found: " + node.filePath);
                continue; // Skip missing files
            }

            let fileName = File.extractName(node.filePath) + ".xisf";
            let destination = savePath + "/" + fileName;

            try {
                let win = ImageWindow.open(node.filePath)[0];
                if (win) {
                    win.saveAs(destination, false, false, false, false);
                    win.close();
                    Console.writeln("Saved: " + destination);
                }
            } catch (error) {
                Console.warningln("Failed to save: " + fileName + " - " + error.message);
            }
        }
    }
}.bind(this);

// --- Save Remaining Button ---
this.saveRemainingButton = new PushButton(this);
this.saveRemainingButton.text = "Save Remaining Images";
this.saveRemainingButton.toolTip = "Save all remaining images to a folder of your choice.";

// --- Save Remaining Images Button ---
this.saveRemainingButton.onClick = function () {
    if (this.treeBox.numberOfChildren === 0) {
        (new MessageBox("No images remaining to save.", "Error", StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let saveDialog = new GetDirectoryDialog();
    saveDialog.caption = "Select Save Location";
    if (saveDialog.execute()) {
        let savePath = saveDialog.directory;
        for (let i = 0; i < this.treeBox.numberOfChildren; i++) {
            let node = this.treeBox.child(i);
            if (!node.filePath || !File.exists(node.filePath)) {
                Console.warningln("File not found: " + node.filePath);
                continue; // Skip missing files
            }

            let fileName = File.extractName(node.filePath) + ".xisf";
            let destination = savePath + "/" + fileName;

            try {
                let win = ImageWindow.open(node.filePath)[0];
                if (win) {
                    win.saveAs(destination, false, false, false, false);
                    win.close();
                    Console.writeln("Saved: " + destination);
                }
            } catch (error) {
                Console.warningln("Failed to save: " + fileName + " - " + error.message);
            }
        }
    }
}.bind(this);

// --- Save Selected Images Button ---
this.saveSelectedButton.onClick = function () {
    let selectedNodes = this.treeBox.selectedNodes;
    if (selectedNodes.length === 0) {
        (new MessageBox("No items selected for saving.", "Error", StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let folderDialog = new GetDirectoryDialog();
    folderDialog.caption = "Select Save Location";
    if (folderDialog.execute()) {
        let savePath = folderDialog.directory;
        for (let node of selectedNodes) {
            if (!node.filePath || !File.exists(node.filePath)) {
                Console.warningln("File not found: " + node.filePath);
                continue; // Skip missing files
            }

            Console.writeln("Saving file: " + node.filePath); // Debugging line
            let fileName = File.extractName(node.filePath) + ".xisf";
            let destination = savePath + "/" + fileName;

            try {
                let win = ImageWindow.open(node.filePath)[0];
                if (win) {
                    win.saveAs(destination, false, false, false, false);
                    win.close();
                    Console.writeln("Saved: " + destination);
                }
            } catch (error) {
                Console.warningln("Failed to save: " + fileName + " - " + error.message);
            }
        }
    }
}.bind(this);

// --- Layout ---
let leftSizer = new VerticalSizer();
leftSizer.margin = 6;
leftSizer.spacing = 6;

// Add components to leftSizer
leftSizer.add(this.instructionLabel);
leftSizer.add(this.viewList);
leftSizer.add(this.addFilesButton);
leftSizer.add(this.subFrameStarCheckBox);
leftSizer.add(this.fullStarCorrectionCheckBox);
leftSizer.add(this.stellarSharpeningSlider);
leftSizer.add(this.nonStellarSharpeningSlider);
leftSizer.add(this.starRemovalCheckBox);
leftSizer.add(this.starRemovalMethodGroup); // Add the radio button group
leftSizer.add(this.resultTextBox);
leftSizer.add(this.measureFWHMButton);
leftSizer.addStretch();
leftSizer.add(this.newInstanceButton);

    // --- Horizontal Layout for Action Buttons ---
let buttonSizer = new HorizontalSizer();
buttonSizer.spacing = 8;

// Ensure the New Instance button is added first
buttonSizer.add(this.newInstanceButton); // Add the New Instance button
buttonSizer.add(this.measureFWHMButton); // Add the Measure FWHM button
buttonSizer.addStretch(); // Add spacing to separate buttons
buttonSizer.add(this.deleteButton); // Add Delete Selected button
buttonSizer.add(this.saveSelectedButton); // Add Save Selected button
buttonSizer.add(this.saveRemainingButton); // Add Save Remaining button

// --- Right Side Layout (TreeBox and Buttons) ---
let rightSizer = new VerticalSizer();
rightSizer.margin = 6;
rightSizer.spacing = 6;

// Add the TreeBox and Button Sizer to the right panel
rightSizer.add(this.treeBox); // Add the TreeBox
rightSizer.addSpacing(8); // Optional spacing for better layout
rightSizer.add(buttonSizer); // Add the Button Sizer

    let mainSizer = new HorizontalSizer();
    mainSizer.margin = 6;
    mainSizer.spacing = 6;
    mainSizer.add(leftSizer);
    mainSizer.add(rightSizer);

    this.sizer = mainSizer;
    this.windowTitle = "Star Console";
}

StarConsoleDialog.prototype = new Dialog;

function main() {
    if (Parameters.isGlobalTarget) {
        // If the new instance is double-clicked, open the dialog
        let dialog = new StarConsoleDialog();
        dialog.loadParameters();
        dialog.execute();
        return;
    }

    if (Parameters.isViewTarget) {
    if (!Parameters.targetView.isNull) {
        let view = Parameters.targetView;
        let fullStarCorrection = Parameters.getBoolean("fullStarCorrection");
        let starRemoval = Parameters.getBoolean("starRemoval");
        let stellarSharpening = Parameters.getReal("stellarSharpening");
        let nonStellarSharpening = Parameters.getReal("nonStellarSharpening");
        let starRemovalMethod = Parameters.has("starRemovalMethod")
            ? Parameters.getString("starRemovalMethod")
            : "None";

        // ✅ Add this line to correctly retrieve Large Overlap setting
        let useLargeOverlap = Parameters.has("enableStarXLargeOverlap")
            ? Parameters.getBoolean("enableStarXLargeOverlap")
            : false; // Default to false if not provided

        // ✅ Pass useLargeOverlap to processImage()
        processImage(view, fullStarCorrection, starRemoval, stellarSharpening, nonStellarSharpening, starRemovalMethod, useLargeOverlap);

        Console.noteln("Processing completed successfully for new instance.");
    } else {
        Console.warningln("No target view available.");
    }
    return;
}

    // Default behavior: Open the dialog
    let dialog = new StarConsoleDialog();
    dialog.execute();
}

main();
