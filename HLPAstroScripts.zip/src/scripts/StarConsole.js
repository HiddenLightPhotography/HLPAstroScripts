#feature-id   StarConsole : HLP > Star Console
#feature-info This script measures FWHM and performs BlurXterminator and StarXterminator

#include <pjsr/StdIcon.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>

function executeBlurXTerminator(view, fwhm) {
    Console.writeln("Executing BlurXTerminator on view: " + view.fullId);

    let P = new BlurXTerminator();
    P.ai_file = "BlurXTerminator.4.pb";
    P.correct_only = false;
    P.correct_first = false;
    P.nonstellar_then_stellar = false;
    P.lum_only = false;
    P.sharpen_stars = 0.50;
    P.adjust_halos = 0.00;
    P.nonstellar_psf_diameter = Math.round(fwhm * 100) / 100; // Round to nearest hundredth
    P.auto_nonstellar_psf = false;
    P.sharpen_nonstellar = 0.50;

    Console.writeln("BlurXTerminator PSF Diameter set to: " + P.nonstellar_psf_diameter);
    P.executeOn(view);

    // Rename the image to include _StarConsole
    let newName = view.id + "_StarConsole";
    view.window.mainView.id = newName;
    Console.writeln("Image renamed to: " + newName);
}

function executeStarXTerminator(view) {
    Console.writeln("Executing StarXTerminator on view: " + view.fullId);

    let P = new StarXTerminator();
    P.ai_file = "StarXTerminator.lite.nonoise.11.pb";
    P.stars = true;
    P.unscreen = true;
    P.overlap = 0.20;

    P.executeOn(view);
    Console.writeln("StarXTerminator executed successfully.");
}

function extractLuminance(view) {
    let P = new ChannelExtraction();
    P.colorSpace = ChannelExtraction.prototype.CIELch;
    P.channels = [[true, ""], [false, ""], [false, ""]];
    P.executeOn(view);

    let activeWindow = ImageWindow.activeWindow;
    if (!activeWindow.isNull) {
        return { view: activeWindow.mainView, window: activeWindow };
    } else {
        throw new Error("Luminance extraction failed.");
    }
}

function saveViewAsTemporaryFile(view) {
    let tempFilePath = File.systemTempDirectory + "/tempImage.xisf";
    try {
        if (!view.window.saveAs(tempFilePath, false, false)) {
            throw new Error("Failed to save the view as a file.");
        }
        return tempFilePath;
    } catch (error) {
        Console.warningln("Error saving temporary file: " + error.message);
        return null;
    }
}

function measureFWHM(filePath, originalView) {
    Console.writeln("Processing file: " + filePath);

    let P = new SubframeSelector();
    P.routine = SubframeSelector.prototype.MeasureSubframes;
    P.nonInteractive = true;
    P.subframes = [[true, filePath, "", ""]];
    P.fileCache = true;
    P.structureLayers = 5;
    P.sensitivity = 0.4;
    P.psfFit = SubframeSelector.prototype.Moffat4;
    P.maxPSFFits = 8000;

    if (!P.executeGlobal()) {
        throw new Error("SubframeSelector execution failed for: " + filePath);
    }

    Console.writeln("SubframeSelector executed successfully.");

    if (P.measurements.length > 0) {
        let measurement = P.measurements[0];
        Console.writeln(
            "FWHM: " + measurement[5] +
            ", Eccentricity: " + measurement[6] +
            ", Stars Detected: " + measurement[14]
        );
        return {
            FWHM: measurement[5],
            Eccentricity: measurement[6],
            StarsDetected: measurement[14],
            ImageName: originalView.fullId,
        };
    } else {
        throw new Error("No valid measurements found in: " + filePath);
    }
}

function processImage(view, fullStarCorrection, starRemoval) {
    let tempFilePath;
    let luminanceWindow = null;
    let originalView = view; // Keep a reference to the original image view

    try {
        if (view.image.isColor) {
            Console.writeln("Detected color image. Extracting luminance...");
            let luminanceResult = extractLuminance(view);
            view = luminanceResult.view;
            luminanceWindow = luminanceResult.window;
        }

        tempFilePath = saveViewAsTemporaryFile(view);
        if (!tempFilePath) {
            throw new Error("Failed to save the temporary file for processing.");
        }

        let result = measureFWHM(tempFilePath, view);
        if (result) {
            if (fullStarCorrection) {
                executeBlurXTerminator(originalView, result.FWHM); // Use the original view
            }
            if (starRemoval) {
                executeStarXTerminator(originalView); // Use the original view
            }
        }

        return result;
    } catch (error) {
        throw error;
    } finally {
        if (tempFilePath) {
            try {
                File.remove(tempFilePath);
                Console.writeln("Deleted temporary file: " + tempFilePath);
            } catch (error) {
                Console.warningln("Failed to delete temporary file: " + error.message);
            }
        }

        if (luminanceWindow) {
            Console.writeln("Closing extracted luminance window...");
            luminanceWindow.forceClose();
        }
    }
}

function StarConsoleDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.originalFileOrder = []; // To track original order for sorting

    // --- Subframe Star Check ---
    this.subFrameStarCheckBox = new CheckBox(this);
    this.subFrameStarCheckBox.text = "SubFrame Star Check";
    this.subFrameStarCheckBox.toolTip = "Check subframes for star properties.";
    this.subFrameStarCheckBox.onCheck = function (checked) {
        if (checked) {
            this.fullStarCorrectionCheckBox.checked = false;
            this.starRemovalCheckBox.checked = false;
            this.fullStarCorrectionCheckBox.enabled = false;
            this.starRemovalCheckBox.enabled = false;
            this.addFilesButton.enabled = true;
            this.viewList.enabled = false;
        } else {
            this.fullStarCorrectionCheckBox.enabled = true;
            this.starRemovalCheckBox.enabled = true;
            this.addFilesButton.enabled = false;
            this.viewList.enabled = true;
        }
    }.bind(this);

    // --- Full Star Correction ---
    this.fullStarCorrectionCheckBox = new CheckBox(this);
    this.fullStarCorrectionCheckBox.text = "Full Star Correction (BlurXTerminator Required)";
    this.fullStarCorrectionCheckBox.toolTip = "Apply BlurXTerminator correction with measured FWHM.";
    this.fullStarCorrectionCheckBox.onCheck = function (checked) {
        if (checked) this.subFrameStarCheckBox.checked = false;
        this.subFrameStarCheckBox.enabled = !this.fullStarCorrectionCheckBox.checked &&
                                             !this.starRemovalCheckBox.checked;
    }.bind(this);

    // --- Star Removal ---
    this.starRemovalCheckBox = new CheckBox(this);
    this.starRemovalCheckBox.text = "Star Removal (StarXTerminator Required)";
    this.starRemovalCheckBox.toolTip = "Remove stars using StarXTerminator.";
    this.starRemovalCheckBox.onCheck = function (checked) {
        if (checked) this.subFrameStarCheckBox.checked = false;
        this.subFrameStarCheckBox.enabled = !this.fullStarCorrectionCheckBox.checked &&
                                             !this.starRemovalCheckBox.checked;
    }.bind(this);

    // --- Instruction Label ---
    // --- Instruction Label ---
this.instructionLabel = new Label(this);
this.instructionLabel.text = "Select an image to analyze its FWHM.\n" +
"Choose Full Star Correction to additionally perform the full BlurXterminator.\n" +
"Choose Star Removal to also remove the stars from your image. \n\n" +
"Select Subframe Star Check and select light frames to get FWHM for each frame.\n" +
"Use the list to select frames to remove from the list, save the selected frames or save remaining frames.\n\n" +
"Written by Tony De Nardo";
this.instructionLabel.textAlignment = TextAlign_Center;
this.instructionLabel.font = new Font("SansSerif", 14); // Change font size to 14

    // --- View List ---
    this.viewList = new ViewList(this);
    this.viewList.getAll();

    // --- Add Light Frame Files Button ---
    this.addFilesButton = new PushButton(this);
    this.addFilesButton.text = "Add Light Subframe Files";
    this.addFilesButton.enabled = false;
    this.addFilesButton.toolTip = "Add light subframe files for batch processing.";
    this.addFilesButton.onClick = function () {
        let fileDialog = new OpenFileDialog();
        fileDialog.multipleSelections = true;
        fileDialog.caption = "Select Light Subframe Files";
        fileDialog.filters = [
            ["All Supported Images", "*.xisf;*.fits;*.fit;*.tif;*.tiff"],
            ["PixInsight Images", "*.xisf"],
            ["FITS Images", "*.fits;*.fit"],
            ["TIFF Images", "*.tif;*.tiff"],
            ["All Files", "*"]
        ];

        if (fileDialog.execute()) {
            let selectedFiles = fileDialog.fileNames;
            this.treeBox.clear(); // Clear the TreeBox for new entries
            this.originalFileOrder = []; // Reset original order
            for (let filePath of selectedFiles) {
                try {
                    let result = measureFWHM(filePath, { fullId: File.extractName(filePath) });
if (result) {
    let node = new TreeBoxNode(this.treeBox);
node.setText(0, File.extractName(filePath)); // Display file name
node.setText(1, result.FWHM.toFixed(4)); // Update FWHM result
node.filePath = filePath; // Store full file path
node.setAlignment(0, TextAlign_Right); // Align text in the "Image Name" column to the right
}
                } catch (error) {
                    Console.warningln("Error processing file: " + filePath + " - " + error.message);
                }
            }
        } else {
            Console.writeln("No files were selected.");
        }
    }.bind(this);

    // --- TreeBox ---
this.treeBox = new TreeBox(this);
this.treeBox.alternateRowColor = true;
this.treeBox.numberOfColumns = 2;
this.treeBox.headerVisible = true;
this.treeBox.setHeaderText(0, "Image Name");
this.treeBox.setHeaderText(1, "FWHM");
this.treeBox.multipleSelection = true;
this.treeBox.setMinHeight(120);
this.treeBox.horizontalScrollBarVisible = true; // Enable horizontal scrolling
this.treeBox.adjustColumnWidthToContents(0); // Dynamically adjust column width to fit content
this.treeBox.setColumnWidth(0, 300); // Example width

    // --- Result TextBox ---
    this.resultTextBox = new TextBox(this);
    this.resultTextBox.readOnly = true;
    this.resultTextBox.styleSheet = "font-family: monospace; font-size: 12pt; padding: 4px;";
    this.resultTextBox.text = "Star Information:\nFWHM\nEccentricity\nStars Detected\nBlurX PSF Diameter Used: None";
    this.resultTextBox.setScaledMinHeight(80);

    // --- Measure FWHM Button ---
    this.measureFWHMButton = new PushButton(this);
    this.measureFWHMButton.text = "Measure FWHM";
    this.measureFWHMButton.toolTip = "Measure FWHM of the selected image.";
    this.measureFWHMButton.onClick = function () {
        let selectedView = this.viewList.currentView;
        if (!selectedView) {
            (new MessageBox("Please select an image view.", "Error", StdIcon_Error, StdButton_Ok)).execute();
            return;
        }
        try {
            let result = processImage(selectedView, this.fullStarCorrectionCheckBox.checked, this.starRemovalCheckBox.checked);
            if (result) {
                let resultText =
                    "Star Information:\n" +
                    "FWHM: " + result.FWHM.toFixed(4) + "\n" +
                    "Eccentricity: " + result.Eccentricity.toFixed(4) + "\n" +
                    "Stars Detected: " + result.StarsDetected;

                // Add BlurX PSF Diameter Used information
                if (this.fullStarCorrectionCheckBox.checked) {
                    let roundedFWHM = Math.round(result.FWHM * 100) / 100;
                    resultText += "\nBlurX PSF Diameter Used: " + roundedFWHM;
                } else {
                    resultText += "\nBlurX PSF Diameter Used: None";
                }

                this.resultTextBox.text = resultText;

                this.treeBox.clear();
                let node = new TreeBoxNode(this.treeBox);
                node.setText(0, result.ImageName);
                node.setText(1, result.FWHM.toFixed(4));
            }
        } catch (error) {
            Console.warningln("Error: " + error.message);
            this.resultTextBox.text = "Star Information:\nError: " + error.message + "\nBlurX PSF Diameter Used: None";
            this.treeBox.clear();
        }
    }.bind(this);

    // --- Action Buttons ---
    this.deleteButton = new PushButton(this);
    this.deleteButton.text = "Delete Selected";
    this.deleteButton.onClick = function () {
        let selectedNodes = this.treeBox.selectedNodes;
        if (selectedNodes.length === 0) {
            (new MessageBox("No items selected for deletion.", "Error", StdIcon_Error, StdButton_Ok)).execute();
            return;
        }
        selectedNodes.forEach(node => this.treeBox.remove(this.treeBox.childIndex(node)));
    }.bind(this);

    // --- Save Selected Button ---
this.saveSelectedButton = new PushButton(this);
this.saveSelectedButton.text = "Save Selected";
this.saveSelectedButton.toolTip = "Save selected images to a folder of your choice.";
this.saveSelectedButton.onClick = function () {
    let selectedNodes = this.treeBox.selectedNodes;
    if (selectedNodes.length === 0) {
        (new MessageBox("No items selected for saving.", "Error", StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let folderDialog = new GetDirectoryDialog();
    folderDialog.caption = "Select Save Location";
    if (folderDialog.execute()) {
        let savePath = folderDialog.directory;
        for (let node of selectedNodes) {
            if (!node.filePath || !File.exists(node.filePath)) {
                Console.warningln("File not found: " + node.filePath);
                continue; // Skip missing files
            }

            let fileName = File.extractName(node.filePath) + ".xisf";
            let destination = savePath + "/" + fileName;

            try {
                let win = ImageWindow.open(node.filePath)[0];
                if (win) {
                    win.saveAs(destination, false, false, false, false);
                    win.close();
                    Console.writeln("Saved: " + destination);
                }
            } catch (error) {
                Console.warningln("Failed to save: " + fileName + " - " + error.message);
            }
        }
    }
}.bind(this);

// --- Save Remaining Button ---
this.saveRemainingButton = new PushButton(this);
this.saveRemainingButton.text = "Save Remaining Images";
this.saveRemainingButton.toolTip = "Save all remaining images to a folder of your choice.";

// --- Save Remaining Images Button ---
this.saveRemainingButton.onClick = function () {
    if (this.treeBox.numberOfChildren === 0) {
        (new MessageBox("No images remaining to save.", "Error", StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let saveDialog = new GetDirectoryDialog();
    saveDialog.caption = "Select Save Location";
    if (saveDialog.execute()) {
        let savePath = saveDialog.directory;
        for (let i = 0; i < this.treeBox.numberOfChildren; i++) {
            let node = this.treeBox.child(i);
            if (!node.filePath || !File.exists(node.filePath)) {
                Console.warningln("File not found: " + node.filePath);
                continue; // Skip missing files
            }

            let fileName = File.extractName(node.filePath) + ".xisf";
            let destination = savePath + "/" + fileName;

            try {
                let win = ImageWindow.open(node.filePath)[0];
                if (win) {
                    win.saveAs(destination, false, false, false, false);
                    win.close();
                    Console.writeln("Saved: " + destination);
                }
            } catch (error) {
                Console.warningln("Failed to save: " + fileName + " - " + error.message);
            }
        }
    }
}.bind(this);

// --- Save Selected Images Button ---
this.saveSelectedButton.onClick = function () {
    let selectedNodes = this.treeBox.selectedNodes;
    if (selectedNodes.length === 0) {
        (new MessageBox("No items selected for saving.", "Error", StdIcon_Error, StdButton_Ok)).execute();
        return;
    }

    let folderDialog = new GetDirectoryDialog();
    folderDialog.caption = "Select Save Location";
    if (folderDialog.execute()) {
        let savePath = folderDialog.directory;
        for (let node of selectedNodes) {
            if (!node.filePath || !File.exists(node.filePath)) {
                Console.warningln("File not found: " + node.filePath);
                continue; // Skip missing files
            }

            Console.writeln("Saving file: " + node.filePath); // Debugging line
            let fileName = File.extractName(node.filePath) + ".xisf";
            let destination = savePath + "/" + fileName;

            try {
                let win = ImageWindow.open(node.filePath)[0];
                if (win) {
                    win.saveAs(destination, false, false, false, false);
                    win.close();
                    Console.writeln("Saved: " + destination);
                }
            } catch (error) {
                Console.warningln("Failed to save: " + fileName + " - " + error.message);
            }
        }
    }
}.bind(this);

    // --- Layout ---
    let leftSizer = new VerticalSizer();
    leftSizer.margin = 6;
    leftSizer.spacing = 6;
    leftSizer.add(this.instructionLabel);
    leftSizer.add(this.subFrameStarCheckBox);
    leftSizer.add(this.fullStarCorrectionCheckBox);
    leftSizer.add(this.starRemovalCheckBox);
    leftSizer.add(this.viewList);
    leftSizer.add(this.addFilesButton);
    leftSizer.add(this.resultTextBox);
    leftSizer.add(this.measureFWHMButton);

    let buttonSizer = new HorizontalSizer();
    buttonSizer.spacing = 8;
    buttonSizer.add(this.deleteButton);
    buttonSizer.add(this.saveSelectedButton);
    buttonSizer.add(this.saveRemainingButton);

    let rightSizer = new VerticalSizer();
    rightSizer.margin = 6;
    rightSizer.spacing = 6;
    rightSizer.add(this.treeBox);
    rightSizer.add(buttonSizer);

    let mainSizer = new HorizontalSizer();
    mainSizer.margin = 6;
    mainSizer.spacing = 6;
    mainSizer.add(leftSizer);
    mainSizer.add(rightSizer);

    this.sizer = mainSizer;
    this.windowTitle = "Star Console";
}

StarConsoleDialog.prototype = new Dialog;

function main() {
    let dialog = new StarConsoleDialog();
    dialog.execute();
}

main();
